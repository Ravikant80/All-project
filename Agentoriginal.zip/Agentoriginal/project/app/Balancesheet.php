<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Balancesheet extends Model
{
    // use SoftDeletes;
}
