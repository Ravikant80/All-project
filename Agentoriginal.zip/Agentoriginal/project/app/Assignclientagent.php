<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assignclientagent extends Model
{
     protected $primaryKey = 'id';
     // use SoftDeletes;
}
