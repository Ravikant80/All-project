<?php
 namespace App\Http\Controllers\Admin\Agent;

  use Illuminate\Http\Request;
  use App\Http\Controllers\Controller;
  use Illuminate\Foundation\Auth\AuthenticatesUsers;
  use Illuminate\Support\Facades\Auth;
  use DB;
  use Session;
  use App\Client;
  use App\Balancesheet;
  use PDF;
  use Maatwebsite\Excel\Facades\Excel;

  class AgentLoginController extends Controller
  {
       use AuthenticatesUsers;

      /**
       * Where to redirect users after login.
       *
       * @var string
       */
      protected $redirectTo = 'AgentDshboard';

      /**
       * Create a new controller instance.
       *
       * @return void
       */
      public function __construct()
      {
          $this->middleware('guest:agent')->except('logout');
      }

       /**
       * Show the application's login form.
       *
       * @return \Illuminate\Http\Response
       */
      public function showLoginForm()
      {
          return view('admin.agent.agent_login');
      }

      /**
       * Get the guard to be used during authentication.
       *
       * @return \Illuminate\Contracts\Auth\StatefulGuard
       */
      protected function guard()
      {
          return Auth::guard('agent');
      }

      public function logout(Request $request) {
         Auth::guard('agent')->logout();
          $request->session()->flush();
          $request->session()->regenerate();
          return redirect('/');
      }



   public function loginuser(Request $request){
 
   $loggedagent= DB::table('agents')
  ->where('email',$request->email) 
  ->where('agent_password',$request->password)
  ->first();
  if(empty($loggedagent)){
  return redirect()->back()->with('message','your password and email do not match');

  }

  else
    {
    Session::put('loggeduser',$loggedagent);
    return redirect('agent-dashboard');

    }

    return 'Agent login successfully'; 

}



  public function getAgentDashboard(){

  if (Session::has('loggeduser')) {

  $data = Session::get('loggeduser');
  $assign= DB::table('assignclientagents')
  ->where('agent_id',$data->agent_id)
  ->get();

  // print_r($assign);
  // die;
  $assignedClient= DB::table('assignclientagents')
 ->join('agents', 'assignclientagents.agent_id', '=', 'agents.agent_id')
 ->join('clients', 'assignclientagents.client_id', '=', 'clients.client_id')
 ->where('agents.agent_id',$data->agent_id)
 ->select('clients.*','agents.*')
  ->get();

    return view('admin.agent.agentdashbord',compact('assign','data','assignedClient'));
  }

    else
    {
      return redirect('agent_login');
            }

}






  public function showMoney(){
    

  if (Session::has('loggeduser')) 
    {
     $data = Session::get('loggeduser');
     $assign= DB::table('assignclientagents')
    ->where('agent_id',$data->agent_id)
    ->get();

      $balance= DB::table('balancesheets')
    ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
    ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
    ->where('agents.agent_id',$data->agent_id)
    ->select('clients.*','agents.*','balancesheets.*')
    ->get();
    return view('admin.agent.showmoney',compact('balance','data','assign'));
  }

        else{

            return redirect('agent_login');
           }
  }



      

public function amtReceive($id){ 

 if(Session::has('loggeduser')) {

      $updateStatus = Balancesheet::where('id',$id)
                    ->update(['status'=>1]);
                      return redirect()->back();
    }  
      else{
    
          return redirect('agent_login');
          }
}


public function amtPending(Request $request,$id){

    if(Session::has('loggeduser')) {
        $updateStatus = Balancesheet::where('id',$id)
                      ->update(['status'=>2]);
                    }

  else{

      return redirect('agent_login');
      }


    
    
  }

  public function downloadPDF(){
  $data = Session::get('loggeduser');
  $assign= DB::table('assignclientagents')
  ->where('agent_id',$data->agent_id)
  ->get();

  $balance= DB::table('balancesheets')
  ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
  ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
  ->where('agents.agent_id',$data->agent_id)
  ->select('clients.*','agents.*','balancesheets.*')
  ->get();
  $pdf = PDF::loadView('admin.agent.showmoney_pdf', compact('balance','data'));
  return $pdf->download('showmoney.pdf');

  }


  public function export($type){
  $user = Session::get('loggeduser');
  $assign= DB::table('assignclientagents')
  ->where('agent_id',$user->agent_id)
  ->get();

  $data= DB::table('balancesheets')
  ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
  ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
  ->where('agents.agent_id',$user->agent_id)
  ->select('clients.client_name','clients.client_contact','clients.client_address','balancesheets.amount','balancesheets.date_of_transfer','balancesheets.status')
  ->get();

  $data= json_decode( json_encode($data), true);
  return Excel::create('showmoney_excel', function($excel) use ($data) {
  $excel->sheet('mySheet', function($sheet) use ($data)
  {
  $sheet->fromArray($data);
  });
  })->download($type);
          

  
    
  }
}








    


          

                    
               

            
      
        
        



















       


