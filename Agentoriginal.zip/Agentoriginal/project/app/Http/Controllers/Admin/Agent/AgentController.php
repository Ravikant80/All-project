<?php

namespace App\Http\Controllers\Admin\Agent;
//use App\Exports\AgentExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Client;
use App\Agent;
use DB;
use PDF;
use App\User;
use Notification;
use App\Notifications\MyFirstNotification;

class AgentController extends Controller
{
     public function agent_index(){
     return view ('admin.agent.agent_index');

     }

    public function regAgentForm(Request $request) {
    return view('admin.agent.register_agent');

     }

        

        public function storeAgent(Request $request)
         {
          //print_r($request->all());
         //die;
          $messages = [
             'agent_contact.required' => 'Phone Number Must Be 10 Digit!',
            ];
            $validator = Validator::make($request->all(), [
            'agent_name' => 'required',
            'agent_address' => 'required|max:255',
            'agent_type' => 'required|max:25',
            'agent_contact' =>'required|min:10',
             'email' => 'required|string| email|max:255|unique:agents',
             'agent_password' => 'required|string|min:6'
     
          ],$messages);

          if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }


        // if($validator->fails()){
        //    return redirect()->back()->with('message','error');
        // }

        $agent = new Agent;
        $agent->agent_name= $request->agent_name;
        $agent->email= $request->email;
        //$agent->agent_password= Hash::make($request->agent_password);
        $agent->agent_password= $request->agent_password;
        $agent->remember_token= $request->_token;
        $agent->agent_address= $request->agent_address;
        $agent->agent_contact= $request->agent_contact;
        $agent->agent_type= $request->agent_type;
        $agent->save();
        return redirect ('agent/show')->with('message','successfully Registered');
    
         }

        public function showAgent(){
            $agents = Agent::all();
             return view('admin.agent.show_agent', compact('agents'));
         }

      

        public function editAgent(Request $request, $id) {
            $data['agent']=Agent::findOrFail($id);
            return view('admin.agent.edit_agent',$data);
            }

       
        public function updateAgent(Request $request, $id){
          DB::table('agents')
            ->where('agent_id', $id)
            ->update([
                    'agent_name' => $request->agent_name,
                    'agent_address' => $request->agent_address,
                    'agent_contact' => $request->agent_contact,
                    'agent_type' => $request->agent_type,
                    'email' => $request->email,
                    'agent_password'=> $request->agent_password,
                    'remember_token'=> $request->_token

                     ]);

        return redirect ('agent/show')->with('message','successfully updated');

         }


            
        public function destroyAgent($id){
         $agent = Agent::find($id);
         $agent->delete();
        return redirect('agent/show')->with('message','successfully deleted');
        }
     
       public function viewAgent($id){   
        $agent = Agent::find($id);
        return view('admin.agent.view-agent', compact('agent'));
        
         }



            public function downloadPDF(){
                $agents = Agent::all();
                $pdf = PDF::loadView('admin.agent.pdf', compact('agents'));
             return $pdf->download('invoice.pdf');

             }

            public function index(){

             // $agents=DB::table('agents')
             //    ->select('agent_id','agent_name','agent_address','agent_contact','email','agent_type')

             //    ->get();

            $agents = Agent::all(); 
            return view('admin.agent.agent_exportexcel')->with('agents', $agents);
             }

        
            public function export($type)
            {
            $data = Agent::select('agent_id','agent_name','agent_address','agent_contact','email','agent_type')
            ->get();

            return Excel::create('AgentRecord', function($excel) use ($data) {
            $excel->sheet('mySheet', function($sheet) use ($data)
            {
                $sheet->fromArray($data);
            });
            })->download($type);
         }

  
    





}
