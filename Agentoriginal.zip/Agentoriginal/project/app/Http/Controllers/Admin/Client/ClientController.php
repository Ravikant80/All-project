<?php
namespace App\Http\Controllers\Admin\Client;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Client;
use DB;
use PDF;
class ClientController extends Controller
{
public function regClientForm(Request $request) {
return view('admin.client.register_client');

 }


public function storeClient(Request $request)
{
//print_r($request->all());
//die;
$messages = [
 'client_contact.required' => 'Phone Number Must Be 10 Digit!',
];
$validator = Validator::make($request->all(), [
'client_name' => 'required',
'client_address' => 'required|max:255',
'client_type' => 'required|max:25',
'client_contact' =>'required|min:10',
 'email' => 'required|string| email|max:255|unique:clients',
 'password' => 'required|string|min:6'

],$messages);

if ($validator->fails()) {
return redirect()->back()
            ->withErrors($validator)
            ->withInput();
}
    $clients = new Client;
    $clients->email= $request->email;
    $clients->password= Hash::make($request->password);
    //$clients->password= $request->password;
    $clients->remember_token= $request->_token;
    $clients->client_name= $request->client_name;
    $clients->client_address= $request->client_address;
    $clients->client_contact= $request->client_contact;
    $clients->client_type= $request->client_type;
    $clients->save();
    return redirect ('client/show')->with('message','successfully Registered');


     }
    public function showClient(){
    $clients = Client::all();
    //  $clients = DB::table('clients')->select(kzz)
    // ->orderBy( 'clients.client_name')
    // ->get();
     return view('admin.client.show_client', compact('clients'))->with('message', 'successfully Deleted');
     }





    public function editClient(Request $request, $id) {
        $data['client']=Client::findOrFail($id);
        return view('admin.client.edit_client',$data);
        }

   
    public function updateClient(Request $request, $id){
    DB::table('clients')
        ->where('client_id', $id)
        ->update([
                'client_name' => $request->client_name,
                'client_address' => $request->client_address,
                'client_contact' => $request->client_contact,
                'client_type' => $request->client_type,
                'email' => $request->email,
                'password'=> $request->password,
                'remember_token'=> $request->_token

                 ]);

    return redirect ('client/show')->with('message','successfully updated');
    }

     public function viewClient($id){
    $client =Client::find($id);
    return view('admin.client.view_client', compact('client'));
    
     }

     public function destroyClient($id){
     $user = Client::find($id);
     $user->delete();
    return redirect ('client/show');
    // ->with('message','successfully deleted');
    }


    public function downloadPDF(){
    $clients = Client::all();
    $pdf = PDF::loadView('admin.client.client_pdf', compact('clients'));
    return $pdf->download('invoice.pdf');

    }

    public function index(){
        $clients = Client::all(); 
        return view('admin.client.client_exportexcel')->with('clients', $clients);
         }

    
    public function export($type)
    {
    $data = Client::select('client_id','client_name','client_address','client_contact','email','client_type')
    ->get();

    return Excel::create('ClientRecord', function($excel) use ($data) {
    $excel->sheet('mySheet', function($sheet) use ($data)
    {
        $sheet->fromArray($data);
    });
    })->download($type);
 }

}
