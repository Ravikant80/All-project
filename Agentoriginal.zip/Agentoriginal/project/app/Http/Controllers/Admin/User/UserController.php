<?php

namespace App\Http\Controllers\Admin\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\NewUser;
use App\Assignclientagent;
use App\User;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DB;

class UserController extends Controller
{
      public function reguserForm(Request $request) {
        return view('admin.user.register_user');

         }

        public function storeUser(Request $request)
         {
          //print_r($request->all());
         //die;
          $messages = [
             'user_contact.required' => 'Phone Number Must Be 10 Digit!',
            ];
            $validator = Validator::make($request->all(), [
            'user_name' => 'required',
            'user_address' => 'required|max:255',
            'user_contact' =>'required|min:10',
             'email' => 'required|string| email|max:255|unique:new_users',
             'password' => 'required|string|min:6'
     
          ],$messages);

          if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }


        // if($validator->fails()){
        //    return redirect()->back()->with('message','error');
        // }

        $user = new NewUser;
        $user->user_name= $request->user_name;
        $user->email= $request->email;
        //$agent->agent_password= Hash::make($request->agent_password);
        $user->password= $request->password;
        $user->remember_token= $request->_token;
        $user->user_address= $request->user_address;
        $user->user_contact= $request->user_contact;
        $user->save();
        return redirect ('/showuser')->with('message','successfully Registered');
    
         }

       public function showUser(){
        $users = NewUser::all();
        return view('admin.user.show_user', compact('users'));
         }

        public function viewUser($id){
        $user =NewUser::find($id);
        return view('admin.user.view_user', compact('user'));
        
         }

         public function edituser(Request $request, $id) {
            $data['user']=NewUser::findOrFail($id);
            return view('admin.user.edit_user',$data);
            }

      public function updateAgent(Request $request, $id){
          DB::table('new_users')
            ->where('id', $id)
            ->update([
                    'user_name' => $request->user_name,
                    'user_address' => $request->user_address,
                    'user_contact' => $request->user_contact,
                    'email' => $request->email,
                    'password'=> $request->password,
                    'remember_token'=> $request->_token

                     ]);

        return redirect ('/showuser')->with('message','successfully updated');

         }

        public function destroyUser($id){
         $user = NewUser::find($id);
         $user->delete();
        return redirect ('/showuser')->with('message','successfully deleted');
        }

        //Client

        
}
