<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use App\Agent;
use App\Client;
use App\Balancesheet;
use App\ Assignclientagent;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DB;
use Notification;
use Session;
use PDF;
use Maatwebsite\Excel\Facades\Excel;
use App\Notifications\DatabseNotification;


class ADashboardController extends Controller
{
      public function __construct(){
       
       $this->middleware('auth:admin');
       }


      public function index(){
      return view ('admin.admin_dashboard.index');

      }

  
      public function getClientAgentData(){
       //fetching data of  three table using join and show getclientdata view
       $client = DB::table('clients')->select('client_id', 'client_name')->get();
       $agent = DB::table('agents')->select('agent_id', 'agent_name')->get();

       $assign= DB::table('assignclientagents')
      ->join('agents', 'assignclientagents.agent_id', '=', 'agents.agent_id')
      ->join('clients', 'assignclientagents.client_id', '=', 'clients.client_id')
      ->select( 'agents.agent_name', 'clients.client_name','assignclientagents.id')
      ->orderByRaw( ' agents.agent_name,clients.client_name')
      ->get();

      return view('admin.getclientdata',compact('client','agent','assign'));
      }


          public function clientagentStore(Request $request){
          $assigndata= DB::table('assignclientagents')
          ->where('agent_id',$request->agent_id) 
          ->where('client_id',$request->client_id)
          ->count();
           
       
           
            if($assigndata >0){
              
              return redirect()->back()->with('message','These Client And Agent Allready Assigned');

            } 
            else{
                $assign = new Assignclientagent;
                $assign->client_id= $request->client_id;
                $assign->agent_id= $request->agent_id;
                //print_r($request->all());
                //die;
                $assign->save();
                return redirect ('/getclientagentdata')->with('message','successfully Assign');
                }
        
          
    }

          public function destroyAssignData($id){
          $assign = Assignclientagent::find($id);
          $assign->delete();
          return redirect()->back()->with('message', 'successfully Deleted!');
          //return redirect ('/getclientagentdata');
          }

                          
            public function ClientAgentData(){

           //fetching data of  three table using join and show transferamount view
           $client = DB::table('clients')->select('client_id', 'client_name')->get();
           $agent = DB::table('agents')->select('agent_id', 'agent_name')->get();
           $amount= DB::table('balancesheets')
          ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
          ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
          ->select('balancesheets.*','agents.*','clients.*')
          ->orderBy('balancesheets.id', 'desc')
          ->get();


            //print_r($amount);
            //die;
          return view('admin.transferamount',compact('client','agent','amount'));
      }


    public function amtStore(Request $request){

        // print_r($request->all());
        //  die;
      $messages = [
                 'amount.required' => 'Please Fill Positive Amount Only!',
            ];
            $validator = Validator::make($request->all(), [
           
             'amount' =>'integer|min:1|'
    ],$messages);

          if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }



        $amount= DB::table('balancesheets')
        ->where('agent_id',$request->agent_id) 
        ->where('client_id',$request->client_id)
        ->where('amount',$request->amount)
        ->count();
       
      // echo $assigndata;
      // die;
       
        if( $amount > 0){
          
          //return redirect()->back()->with('message','These Client And Agent Allready Assigned');
          return redirect ('/amttransfer')->with('message', 'These Client And Agent Allready Assigned');
        }

        else{
       
            $transfer = new Balancesheet;
            $transfer->client_id= $request->client_id;
            $transfer->agent_id= $request->agent_id;
            $transfer->amount= $request->amount;
            $transfer->date_of_transfer= now();
            // $transfer->date_of_transfer = \Carbon\Carbon::parse($balancesheets->created_at)->format('d/m/Y');
            // $transfer->update(['status' => 1]);
            // // print_r($request->all());
            // die;
            $transfer->save();
            return redirect ('/amttransfer')->with('message','Amount Successfully Assigned');
            }

  }

          public function destroyAmt($id){
          $amount = Balancesheet::findOrFail($id);
          $amount->delete();

          //return redirect()->back()->with('message', 'successfully Deleted!');
          return redirect ('/amttransfer')->with('message', 'successfully Deleted!');
          }

   
          public function assignMoneyPDF(){

          $balance= DB::table('balancesheets')
          ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
          ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
          ->select('clients.*','agents.*','balancesheets.*')
          ->get();
           // print_r($balance);
           // die;
          $pdf = PDF::loadView('admin.assignmoney_pdf',compact('balance'));
          return $pdf->download('Assignmoney.pdf');

          }

         public function export($type)
          {

          $data= DB::table('balancesheets')
          ->join('agents', 'balancesheets.agent_id', '=', 'agents.agent_id')
          ->join('clients', 'balancesheets.client_id', '=', 'clients.client_id')
          ->select('clients.client_name','agents.agent_name','balancesheets.amount','balancesheets.date_of_transfer','balancesheets.status')
          ->get();
            $data= json_decode( json_encode($data), true);
            return Excel::create('AgentRecord', function($excel) use ($data) {
            $excel->sheet('mySheet', function($sheet) use ($data)
            {
                $sheet->fromArray($data);
            });
            })->download($type);
          }



        //   Public function findDateRecord(Request $request){
        //     $start=$request->start;
        //     $end=$request->end; 
        //     print_r($request->all());
        //     // die;
        
        //    $data= DB::table('balancesheets')
        //     ->whereBetween('created_at',[$start,$end])
        //     ->get();

        //     print_r($data);
        //      die;
        
        // // return redirect()->back();
        // }

          
     
}       
            
        

        








               



                         
                         
                    
              
                          
                   





              
              
                 
              





              

              
                  

                          
                          

                  
                           
              





                            
                         
                     
                           
                           


                        

                      
                          	


                   
                           
                               

                   
                  
                   
               







                  

