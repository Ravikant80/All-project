      
      
        
        <?php $__env->startSection('contents'); ?>

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Agent Record </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>AgentID</th>
                      <th>AgentName</th>
                      <th>AgentContact</th>
                      <th>AgentType</th>
                      <th>AgentBalance</th>
                      
                    </tr>

                  </thead>
                  <tfoot>
                     <tr>
                      <th>AgentID</th>
                      <th>AgentName</th>
                      <th>AgentContact</th>
                      <th>AgentType</th>
                      <th>AgentBalance</th>
                      
                    
                    </tr>
                  </tfoot>

                  <tbody>
                     <?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->agent_id); ?></td>
            <td><?php echo e($value->agent_name); ?></td>
            <td><?php echo e($value->agent_address); ?></td>
            <td><?php echo e($value->agent_contact); ?></td>
            <td><?php echo e($value->agent_type); ?></td>
            <td><?php echo e($value->agent_balance); ?></td>
            
<!----href

<a href="<?php echo e(route('shares.edit',$share->id)); ?>" class="btn btn-primary">Edit</a></td>

             <td><a href="<?php echo e(route('shares.show',$share->id)); ?>" class="btn btn-primary">show</a></td>

            <td>
                <form action="<?php echo e(route('shares.destroy', $share->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
               
                </form>
               ------> 
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
                  
                </table>
              </div>
            </div>



           
          </div>

        </div>
        <!-- /.container-fluid -->

        <?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>