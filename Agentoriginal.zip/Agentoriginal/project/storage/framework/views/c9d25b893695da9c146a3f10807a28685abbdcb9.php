       
  <?php $__env->startSection('contents'); ?>

<!-- <?php if(session('message')): ?>
<p class="alert alert-success"></p>
<?php endif; ?> -->
  
          <!-- DataTables Example -->

<div class="card mb-3">
  <div class="card-header">
  <i class="fas fa-table"></i>
    <h4> Hi 
      <?php echo e($data->agent_name); ?>

        Your Transfer Money Details
          <h4> 
          </div>
             <div class="card-body">
                <div class="table-responsive">

    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
          <tr>
          <th>ClientName</th>
            <th>ClientAddress</th>
               <th> ClientContact</th>
               <th>PaymentReceive</th>
               <th>DateOfAmtReceive</th>
                 </tr>
             </thead>

              <tbody>
                <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr> 
                     <td><?php echo e($balances->client_name); ?></td>
                        <td><?php echo e($balances->client_address); ?></td>
                           <td><?php echo e($balances->client_contact); ?></td>
                             <td><?php echo e($balances->amount); ?></td>
                             <td><?php echo e($balances->date_of_transfer); ?></td>
                               </tr>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                   
                                  </tbody>
                                      </table>

                              </div>
                            </div>         
                        </div>


  <div class="card mb-3">
  <div class="card-header">
  <i class="fas fa-table"></i>
    <h4> Hi 
      <?php echo e($data->agent_name); ?>

          Your Assign Clients Details
          <h4> 
          </div>
             <div class="card-body">
                <div class="table-responsive">

    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
          <tr>
          <th>ClientName</th>
            <th>ClientAddress</th>
               <th> ClientContact</th>
                 </tr>
             </thead>

              <tbody>
                <?php $__currentLoopData = $assignedClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedClients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr> 
                     <td><?php echo e($assignedClients->client_name); ?></td>
                        <td><?php echo e($assignedClients->client_address); ?></td>
                           <td><?php echo e($assignedClients->client_contact); ?></td>
        
                               </tr>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                   
                                  </tbody>
                                      </table>

                              </div>
                            </div>         
                        </div>
                  
                  

         

<!-- <script>
  function myFunction() {
      if(!confirm("Are You Sure to delete this"))
      event.preventDefault();
  }
 </script> -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>