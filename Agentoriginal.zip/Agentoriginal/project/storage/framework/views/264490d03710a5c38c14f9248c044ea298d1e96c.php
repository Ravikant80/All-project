             
        <?php $__env->startSection('contents'); ?>


        <?php if(session('message')): ?>
        <p class="alert alert-success"></p>
        <?php endif; ?>
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Register</a>
        </li>
        <li class="breadcrumb-item active">User</li>
        </ol>

        <form method="post" id="add_user_form_id" action=" <?php echo e(url('/user/store')); ?>" >
        <?php echo csrf_field(); ?>

        <div class="form-row">
          <div class="form-group col-md-8">
            <label for="agent_name">User Name</label>
            <input type="text" name="user_name" class="form-control" id="user_name" placeholder="User Name" autocomplete="off" required="must be fill">
             <span id="name" class="text-danger font-weight-bold"></span>
          </div>
        </div>


        <div class="form-row">
          <div class="form-group col-md-8">
            <label for="user_balance">User Balance</label>
            <input type="text" name="user_balance" class="form-control number" id="user_balance" placeholder="Balance Only Number" autocomplete="off" required="must be fill">
             <span id="balance" class="text-danger font-weight-bold"></span>
          </div>
        </div>

        <button type="submit" id="submit_btn" class="btn btn-primary" value="submit">Register</button>
        </form>


          

        <?php $__env->stopSection(); ?>


              
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>