      
  <?php $__env->startSection('contents'); ?>
            <!-- Breadcrumbs-->
  <ol class="breadcrumb">
       <li class="breadcrumb-item">
         <a href="#">Edit</a>
     </li>
         <li class="breadcrumb-item active">Agent</li>
     </ol>

     <form method="post" action="<?php echo e(url('agent/update-profile/'.$agent->agent_id)); ?>">
          <?php echo csrf_field(); ?>

     
  <div class="form-group">
    <label for="client_name">Agent Name</label>
    <input type="text" name="agent_name" class="form-control" id="agent_name" placeholder=" Name" value="<?php echo e($agent->agent_name); ?>">
  </div>

     <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4"> Email</label>
          <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" placeholder="rk@gmail123.com" name="email" value="<?php echo e($agent->email); ?>">

           <?php if($errors->has('email')): ?>
           <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
      </div>

      <div class="form-group col-md-6">
          <label for="inputPassword4"> Password</label>
          <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="password" placeholder="Password" name="password"  value="<?php echo e($agent->password); ?>" >

            <?php if($errors->has('password')): ?>
             <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('Password')); ?></strong>
            </span>
            <?php endif; ?> 
                </div>
                   </div>

  <div class="form-row">
   <!--  <div class="form-group col-md-6">
      <label for="agent_date">Date</label>
      <input type="text" name="bal_deposite_date" class="form-control" id="agent_date" placeholder="2018-04-27" autocomplete="off">
    </div> -->
<div class="form-group col-md-12">
 <label for="agent_contact">Agent Contact</label>
     <input type="number" name="agent_contact" class="form-control <?php echo e($errors->has('agent_contact') ? ' is-invalid' : 'Phone Number is invalid'); ?>" id="agent_contact" placeholder="9809876543" value="<?php echo e($agent->agent_contact); ?>" >
             <?php if($errors->has('agent_contact')): ?>
               <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('agent_contact')); ?></strong>
                       </span>
                          <?php endif; ?>
                              </div>
                                 </div>



 <div class="form-group">
      <label for="agent_address">Agent Address</label>
           <input type="text" name="agent_address" class="form-control" id="agent_address" placeholder="1234 Main St" value="<?php echo e($agent->agent_address); ?>" >
              </div>
      <select class="browser-default custom-select" name="agent_type" value="<?php echo e($agent->agent_type); ?>">
        <option selected>Choose Client Type</option>
          <option value="Regular">Regular</option>
            <option value="Part time">Part Time</option>
              <option value="Full Time">Full Time</option>
              </select><br>

  


  <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Update</button>
</form>

  <?php $__env->stopSection(); ?>




        
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>