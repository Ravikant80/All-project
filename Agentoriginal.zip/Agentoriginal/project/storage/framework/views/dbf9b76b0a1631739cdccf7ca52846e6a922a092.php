       
  <?php $__env->startSection('contents'); ?>


        <!-- DataTables Example -->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fas fa-table"></i>
        Agent Record </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            
            <thead>
              <tr>
                  <th>No</th>
                   <th>UserName</th>
                    <th>UserBalance</th>
                      <th>Action</th>
                    </tr>
                </thead>
                  
                 <tbody>

                <tr>
               <td><?php echo e($user->id); ?></td> 
                 <td><?php echo e($user->user_name); ?></td>
                    <td><?php echo e($user->user_balance); ?></td>
                      <td>
                        <a href="<?php echo e(URL::previous('showuser')); ?>">Go Back</a>
                        <a href="<?php echo e(url('user/delete-profile/'.$user->id )); ?>"> Delete</a>
                        </td>  
                    </tr> 
                                    
                
            </tbody>
          </table>
        </div>
      </div>         
</div>

</div>

<?php $__env->stopSection(); ?>
                
                
          
               
                
                
                
                
                 
                    
                        
             
      
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>