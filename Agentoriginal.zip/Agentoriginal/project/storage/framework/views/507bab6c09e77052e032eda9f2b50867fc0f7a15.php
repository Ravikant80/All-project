       
  <?php $__env->startSection('contents'); ?>

<?php if(session('message')): ?>
<p class="alert alert-success"></p>
<?php endif; ?>
  
          <!-- DataTables Example -->

    <div class="card mb-3">
      <div class="card-header">

        <i class="fas fa-table"></i>
        Users Record </div>
       <div class="card-body">
            <a href="<?php echo e(url('/user/register')); ?>" class="btn btn-secondary mb-3" >Register</a>

            

              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          


            <thead>

              <tr>
                <th>No</th>
                 <th>UserName</th>
                  <th>UserBalance</th>
                    <th>Action</th> 
                    </tr> 
                </thead>
                 
            <tbody>
               <?php if(count($users)): ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->user_name); ?></td>
                <td><?php echo e($user->user_balance); ?></td>

                  <td>
                   &nbsp;<a href="<?php echo e(url('user/view-profile/'.$user->id )); ?>">View</a>
                   &nbsp;<a href="<?php echo e(url('user/edit-profile/'. $user->id )); ?>"> Edit</a>
                        <a href="<?php echo e(url('user/delete-profile/'. $user->id )); ?>"> Delete</a>
                    </td>  
                    </tr> 
                 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                              
             
            </tbody>
          </table>
        </div>
      </div>         
</div>
</div>
<?php $__env->stopSection(); ?>

                
                
                 
                
           
          
                
    



            
                  
         

            
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>