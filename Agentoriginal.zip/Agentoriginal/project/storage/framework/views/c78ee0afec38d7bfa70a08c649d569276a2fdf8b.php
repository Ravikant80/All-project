        <ul class="sidebar navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(url ( 'ADshboard' )); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Admin Dashboard</span>
              </a>
             </li>

            <!--  <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('showuser')); ?>">
                  <i class="fas fa-fw fa-user-circle"></i>
                    <span>User Data</span>
                    </a>
                </li>

 -->
        <!--
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('admin-agent-form')); ?>">
        <i class="fas fa-fw fa-user-circle"></i>
        <span>Register agent</span>
        </a>

        </li>

        -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
            <span>Client</span>
            </a>

        <div class="dropdown-menu" aria-labelledby="pagesDropdown" x-placement="bottom-start" style="position:   absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(5px, 56px, 0px);">
          <a class="dropdown-item" href="<?php echo e(url('/client/add')); ?>">Register Client</a>
          <a class="dropdown-item" href="<?php echo e(url('client/show')); ?>">All Client</a>
           </div>
              </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('getclientagentdata')); ?>">
          <i class="fas fa-fw fa-user-circle"></i>
            <span>AssignClient</span>
            </a>
              </li>


              <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown"     aria-haspopup="true" aria-expanded="false">
                 <i class="fas fa-fw fa-folder"></i>
                  <span>Agents</span>
              </a>
                <div class="dropdown-menu" aria-labelledby="pagesDropdown" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(5px, 56px, 0px);">
                  <a class="dropdown-item" href="<?php echo e(url('agent/add')); ?>">Register Agent</a>
                    <a class="dropdown-item" href="<?php echo e(url('agent/show')); ?>">All Agents</a>
                </div>
                  </li>

                  <li class="nav-item">
                       <a class="nav-link" href="<?php echo e(url('amttransfer')); ?>">
                           <i class="fas fa-fw fa-user-circle"></i>
                             <span>AssignAmount</span>
                        </a>
                     </li>





        <!-----
        <li class="nav-item">
        <a class="nav-link" href="tables.html">
        <i class="fas fa-fw fa-table"></i>
        <span>Tables</span></a>
        </li>
        -->
        </ul>