      
  <?php $__env->startSection('contents'); ?>

    <?php if(session('message')): ?>
    <p class="alert alert-success"></p>
    <?php endif; ?>

    <!-----Breadcrumb----->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
        <a href="#">Register</a>
        </li>
        <li class="breadcrumb-item active">Agent</li>
      </ol>
    <form method="post" id="add_agent_form_id" action=" <?php echo e(url('/agent/store')); ?> "  class="bg-light" >
        <?php echo csrf_field(); ?>

<div class="form-row">
<div class="form-group col-md-6">
      <label for="agent_name">Agent Name</label>
      <input type="text" name="agent_name" class="form-control" id="agent_name" placeholder="Agent Name" autocomplete="off" onkeyup="validate();">
     <td><div id="errname"></div></td>
 </div>


      <div class="form-group col-md-6">
        <label for="agent_contact">Agent Contact</label>
         <input type="text" name="agent_contact" class="form-control number" id="agent_contact" placeholder="9809876543" autocomplete="off" onkeyup="validate();">
      <td><div id="errcontact"></div></td>
    </div>
</div>

<div class="form-group">
      <label for="agent_address">Agent Address</label>
        <input type="text" name="agent_address" class="form-control" id="agent_address" placeholder="1234 Main St" autocomplete="off" onkeyup="validate();">
    <td><div id="erraddress"></div></td>
  </div>

<div class="form-row">
  <div class="form-group col-md-12">
    <label for="agent_type">Agent Type</label>
    <input type="text" name="agent_type" id="agent_type" class="form-control"  autocomplete="off" onkeyup="validate();">
  
  <td><div id="errtype"></div></td>
    </div>
</div>


  <button type="submit" id="submit_btn" class="btn btn-primary" value="submit"  onclick="validate();finalValidate();">Register</button>
</form>


  <script type="text/javascript">
    var divs = new Array();
    divs[0] = "errname";
    divs[1] = "errcontact";
    divs[2] = "erraddress";
    divs[3] = "errtype";
    function validate()
  {
      var inputs = new Array();
      inputs[0] = document.getElementById('agent_name').value;
      inputs[1] = document.getElementById('agent_contact').value;
      inputs[2] = document.getElementById('agent_address').value;
      inputs[3] = document.getElementById('agent_type').value;
      var errors = new Array();
      errors[0] = "<span style='color:red'>Please enter your first name!</span>";
      errors[1] = "<span style='color:red'>Please enter your last name!</span>";
      errors[2] = "<span style='color:red'>Please enter your email!</span>";
      errors[3] = "<span style='color:red'>Please enter your user id!</span>";
    

                 
         



for (i in inputs)
      {
        var errMessage = errors[i];
        var div = divs[i];
        if (inputs[i] == "")
          document.getElementById(div).innerHTML = errMessage;
        
          else
          document.getElementById(div).innerHTML = "OK!";
        }
      
          
       
     
        function finalValidate()
        {
          var count = 0;
          for(i=0;i<6;i++)
          {
            var div = divs[i];
            if(document.getElementById(div).innerHTML == "OK!")
            count = count + 1;
          }
          if(count == 6)
            document.getElementById("errFinal").innerHTML = "All the data you entered is correct!!!";
        }
   </script>

   <?php $__env->stopSection(); ?>

      









 

       
     

     


  








            



           



                  
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>