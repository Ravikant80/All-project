       
  <?php $__env->startSection('contents'); ?>
  <div class="card mb-3">
    <div class="card-header">
      <i class="fas fa-table"></i>
      <center>
              <h5 style="color:#008080;">
                   Hi 
                  <?php echo e($data->agent_name); ?>

                  Your Assign Clients Details
              <h5> 
      </center>
        </div>
       <div class="card-body">
    <div class="table-responsive">

    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
          <tr>
          <th>ClientName</th>
            <th>ClientAddress</th>
               <th> ClientContact</th>
              <!--  <th> ClientEmail</th> -->
                 </tr>
             </thead>

              <tbody>
                <?php $__currentLoopData = $assignedClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedClients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr> 
                     <td><?php echo e($assignedClients->client_name); ?></td>
                        <td><?php echo e($assignedClients->client_address); ?></td>
                           <td><?php echo e($assignedClients->client_contact); ?></td>
        
                               </tr>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                   
                                  </tbody>
                          </table>

                              </div>
                            </div>         
                        </div>
  					         <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>