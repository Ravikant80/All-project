       
  <?php $__env->startSection('contents'); ?>

<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="#">Assign</a>
  </li>
  <li class="breadcrumb-item active">Client & Agent</li>
</ol>
<div class="container">
  <form method="post" action="<?php echo e(url ('clientagentstore')); ?>">
  	 <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="row"></div>
     <label for="sel2"><b>SelectClient</b></label>

      <select multiple class="form-control" id="sel2" name="client_id">
      	 <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       				 <option value="<?php echo e($clients->client_id); ?>" ><?php echo e($clients->client_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       			
      	</select>

       <div class="form-group">
     	<label for="sel2" class="mt-4"><b>SelectAgent</b></label>

      	<select multiple class="form-control mt-2" id="sel3" name="agent_id">
        <?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       	<option value="<?php echo e($agents->agent_id); ?>" ><?php echo e($agents->agent_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <center> <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Assign</button><center>


  </form>
</div>
<!-- 
<?php if(Session::has('message')): ?>
<div id="alerts">
  <div class="alert alert-dismissable alert-<?php echo e(Session::get('alert-class alert-danger', 'success')); ?>"><?php echo e(Session::get('message')); ?>

    <button class="close" role="close" data-dismiss="alert">&times;</button>
  </div>
</div>
<?php endif; ?>
 -->
   <div class="alert alert-success fade in">
    <a href="<?php echo e(url ('clientagentstore')); ?>" class="close" data-dismiss="alert">&times;</a>
    <strong>Success!</strong> Successfully Assign.
</div>



          <!-- DataTables Example -->

    <div class="card mb-3">
      <div class="card-header">
        <i class="fas fa-table"></i>
        Assign Record </div>
       <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>ClientName</th>
                <th>AgentName</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $assign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr> 
                   <td><?php echo e($assigns->client_name); ?></td>
                   <td><?php echo e($assigns->agent_name); ?></td>
                    <td>
                  <a href="<?php echo e(url('assignclient/delete-profile/'.$assigns->id )); ?>" onclick="return myFunction();"> Delete</a>
                    </td>
                </tr>     
             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            </tbody>
          </table>
        </div>
      </div>         
  </div>
</div>

<script>
  function myFunction() {
      if(!confirm("!! Are You Sure Delete AgentName And ClientName"))
      event.preventDefault();
  }
 </script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>