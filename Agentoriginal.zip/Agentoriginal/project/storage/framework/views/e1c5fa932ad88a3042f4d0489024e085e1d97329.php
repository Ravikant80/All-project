     
<?php $__env->startSection('contents'); ?>




 <!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="#">Register</a>
  </li>
  <li class="breadcrumb-item active">Client</li>
</ol>

<?php if(Session::has('message')): ?>
    <div class="alert alert-info">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form method="post" id="add_agent_form_id" action=" <?php echo e(url('/client/store')); ?>" >
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="client_name">Client Name</label>
    <input type="text" name="client_name" class="form-control" id="client_name" placeholder="Client Name" value="<?php echo e(old('client_name')); ?>">
  </div>


  <div class="form-row">
   <!--  <div class="form-group col-md-6">
      <label for="agent_date">Date</label>
      <input type="text" name="bal_deposite_date" class="form-control" id="agent_date" placeholder="2018-04-27" autocomplete="off">
    </div> -->
    <div class="form-group col-md-12">
      <label for="agent_contact">Client Contact</label>
      <input type="number" name="client_contact" class="form-control <?php echo e($errors->has('client_contact') ? ' is-invalid' : 'Phone Number is invalid'); ?>" id="agent_contact" placeholder="9809876543" value="<?php echo e(old('client_contact')); ?>" >
      <?php if($errors->has('client_contact')): ?>
         <span class="invalid-feedback" role="alert">
        <strong><?php echo e($errors->first('client_contact')); ?></strong>
        </span>
         <?php endif; ?>
    </div>
  </div>

  <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4"> Email</label>
          <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" placeholder="rk@gmail123.com" name="email"   value="<?php echo e(old('email')); ?>">

           <?php if($errors->has('email')): ?>
           <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
      </div>

      <div class="form-group col-md-6">
          <label for="inputPassword4"> Password</label>
          <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" id="password" placeholder="Password" name="password"  value="<?php echo e(old('password')); ?>" >

            <?php if($errors->has('password')): ?>
             <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('Password')); ?></strong>
            </span>
            <?php endif; ?> 
    </div>
  </div>



  <div class="form-group">
    <label for="agent_address">Client Address</label>
    <input type="text" name="client_address" class="form-control" id="client_address" placeholder="1234 Main St" value="<?php echo e(old('client_contact')); ?>" >

  </div>
<select class="browser-default custom-select" name="client_type">
  <option selected>Choose Client Type</option>
  <option value="Regular">Regular</option>
  <option value="Part time">Part Time</option>
  <option value="Full Time">Full Time</option>
</select><br>

  


  <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Register</button>
</form>

<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>