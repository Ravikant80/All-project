       
  <?php $__env->startSection('contents'); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>