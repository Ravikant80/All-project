       
  <?php $__env->startSection('contents'); ?>
  <style> 
     a.btn:hover {
     -webkit-transform: scale(1.1);
     -moz-transform: scale(1.1);
     -o-transform: scale(1.1);
    }
 a.btn {
     -webkit-transform: scale(0.8);
     -moz-transform: scale(0.8);
     -o-transform: scale(0.8);
     -webkit-transition-duration: 0.5s;
     -moz-transition-duration: 0.5s;
     -o-transition-duration: 0.5s;
 }
</style>                       
   <!-- DataTables Example -->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fas fa-table"></i>
        Agent Record </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>No</th>
                <th>AgentName</th>
                <th>AgentAddress</th>
                <th>AgentContact</th>
                <th>Deposit_Date</th>
                <th>AgentType</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><?php echo e($agent->agent_id); ?></td>
                <td><?php echo e($agent->agent_name); ?></td>
                <td><?php echo e($agent->agent_address); ?></td>
                <td><?php echo e($agent->agent_contact); ?></td>
                <td><?php echo e($agent->bal_deposite_date); ?></td>
                <td><?php echo e($agent->agent_type); ?></td>
              
                      <td>
                        <!-- <a href="<?php echo e(URL::previous('agentshow')); ?>">Go Back</a>
                        <a href="<?php echo e(url('agent/delete-profile/'.$agent->agent_id )); ?>"> Delete</a> -->

                         <a href="<?php echo e(URL::previous('agent/show')); ?>"class="btn btn-primary a-btn-slide-text">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        <span><strong>Go Back</strong></span>            
                        </a>
                        <a href="<?php echo e(url('agent/delete-profile/'.$agent->agent_id )); ?>" onclick="return myFunction();" class="btn btn-primary a-btn-slide-text">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        <span><strong>Delete</strong></span>            
                        </a>

                    </td>  
                    </tr>     
            </tbody>
          </table>
        </div>
      </div>         
</div>
</div>
 <script>
  function myFunction() {
      if(!confirm("Are You Sure to delete this"))
      event.preventDefault();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>