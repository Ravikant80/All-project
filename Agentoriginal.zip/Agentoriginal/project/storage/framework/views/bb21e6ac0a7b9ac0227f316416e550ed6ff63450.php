<html>
  <head>
    <meta charset="utf-8">
    <title></title>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

          <!-- Bootstrap core CSS-->
          <link href="<?php echo e(asset('asset/admin/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

          <!-- Custom fonts for this template-->
          <link href="<?php echo e(asset('asset/admin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

          <!-- Page level plugin CSS-->
          <link href="<?php echo e(asset('asset/admin/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">

          <!-- Custom styles for this template-->
          <link href="<?php echo e(asset('asset/css/sb-admin.css')); ?>" rel="stylesheet">
          <link href="<?php echo e(asset('asset/css/custome.css')); ?>" rel="stylesheet">

  </head>
  <body>
    <div>
     <h2>
       Agent Record
     </h2> 
    </div>
    <table class="table table-bordered">
       <thead>
                 <tr>
                  <th>No</th>
                  <th>AgentName</th>
                  <th>AgentEmail</th>
                  <th>AgentAddress</th>
                  <th>AgentContact</th>
                  <th>AgentType</th>
                 </tr>
               </thead>

              <tbody>

                <?php if(count($agents)): ?>
                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($agent->agent_id); ?></td>
                    <td><?php echo e($agent->agent_name); ?></td>
                    <td><?php echo e($agent->email); ?></td>
                    <td ><?php echo wordwrap($agent->agent_address,15,"<br>\n");?></td>
                    <td><?php echo e($agent->agent_contact); ?></td>
                    <td><?php echo e($agent->agent_type); ?></td>
                    
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php endif; ?>
                                  </tbody>
                                </table>  
                              </body>
                          </html>




    