     
<?php $__env->startSection('contents'); ?>




 <!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="#">Fund</a>
  </li>
  <li class="breadcrumb-item active">Transfer</li>
</ol>

<?php if(Session::has('message')): ?>
    <div class="alert alert-info">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form method="post" id="add_agent_form_id" action=" <?php echo e(url('fundtransfer/store')); ?>" >
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="amount_receive">Amount Receive</label>
    <input type="text" name="amount_receive" class="form-control" id="amount_receive" placeholder="Enter Amount" value="<?php echo e(old('amount_receive')); ?>">
  </div>



<select class="browser-default custom-select" name="agent_purpose">
  <label for="purpose"> purpose</label>
  <option selected>Purpose</option>
  <option value="PaymentTransfer">PaymentTransfer</option>
  <option value="Deposit Investment">Deposit Investment</option>
  <option value="Gift">Gift</option>
   <option value="Eduction">Eduction</option>
  <option value="Other">Other</option>
</select>
  <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Submit</button>
</form>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>