 
  <?php $__env->startSection('contents'); ?>
    <div class="card mb-3">
      <div class="card-header">
        <i class="fas fa-table"></i>
        Assign Record </div>
       <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>ClientName</th>
                <th>ClientAdress</th>
                <th>ClientContact</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $assign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr> 
                   <td><?php echo e($assigns->client_name); ?></td>
                   <td><?php echo e($assigns->client_address); ?></td>
                    <td><?php echo e($assigns->client_contact); ?></td>
                    <td>
                  <a href="<?php echo e(url('assignclient/delete-profile/'.$assigns->id )); ?>" onclick="return myFunction();"> Delete</a>
                    </td>
                </tr>     
             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            </tbody>
          </table>
        </div>
      </div>         
  </div>
</div>

<script>
  function myFunction() {
      if(!confirm("!! Are You Sure Delete AgentName And ClientName"))
      event.preventDefault();
  }
 </script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agent_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>