       
  <?php $__env->startSection('contents'); ?>

<a href="<?php echo e(URL::to('agent/showmoney_excel/xls')); ?>"><button type="button" class="btn btn-outline-warning mb-2 mr-2">Download Excel xls</button></a>
<a href="<?php echo e(url ('agent/showMoneyPDF')); ?>"><button type="button" class="btn btn-outline-danger mb-2">Download to PDF</button></a>

<div class="card mb-3">
  <div class="card-header">
  <i class="fas fa-table"></i>

     <center> 

        <h5 style="color:#008080;"> 
         Hi 
         <?php echo e($data->agent_name); ?>

          You Need To Collect Money 
          <h5>

      </center>
          </div>
              <div class="card-body">
                <div class="table-responsive">
   

        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                  <th>ClientName</th>
                  <th>ClientAddress</th>
                  <th> ClientContact</th>
                  <th>AssignAmount</th>
                  <th>DateOfAmtAssign</th>
                  <!--  <th>updated_at</th> -->
                  <th>Status</th>
                  <th>Action</th>
                  </tr>
               </thead>

                <tbody>
                <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr> 
                    <td><?php echo e($balances->client_name); ?></td>
                    <td><?php echo e($balances->client_address); ?></td>
                    <td><?php echo e($balances->client_contact); ?></td>
                    <td><?php echo e($balances->amount); ?></td>
                    <td><?php echo e($balances->date_of_transfer); ?></td>
                   <!--  <td><?php echo e($balances->updated_at); ?></td> -->

                    <td>
                    
                    <?php if($balances->status === 1): ?>
                    <a href="javascript:void(0);"  class="btn btn-primary btn-sm active">Receive</a>
                    <?php elseif($balances->status === 2): ?>
                    <a href="javascript:void(0);"class="btn btn-primary btn-sm active">Reject</a>
                    <?php else: ?>
                    <a href="javascript:void(0);"class="btn btn-primary btn-sm active">pending</a>
                    <?php endif; ?>  
                      
                       
                    </td> 
                    <td>
                      <?php if($balances->status === 0): ?>
                      &nbsp;<a href="<?php echo e(url('agent/receive_money/'.$balances->id )); ?>"  class="btn btn-primary btn-sm active">Accept</a>
                      &nbsp;<a href="<?php echo e(url('agent/reject_money/'.$balances->id )); ?>"  class="btn btn-danger btn-sm active">Reject</a>

                       <?php elseif($balances->status === 1): ?>
                        &nbsp;<a href="javascript:void(0);"  class="btn btn-primary btn-sm active">Receive</a>
                        
                     

                       <?php elseif($balances->status === 2): ?>
                        &nbsp;<a href="javascript:void(0);"  class="btn btn-danger btn-sm active">Reject</a>
                        
                        <?php endif; ?>

                    </td>


              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>         
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.agent_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>