     
<?php $__env->startSection('contents'); ?>

 <!-- Breadcrumbs-->
          <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Register</a>
          </li>
          <li class="breadcrumb-item active">Agent</li>
          </ol>

          <?php if(Session::has('message')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>



         

<form method="post" id="add_agent_form_id" action=" <?php echo e(url('/agent/store')); ?>" >
  <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="agent_name">Agen Name</label>
       <input type="text" name="agent_name" class="form-control" id="agent_name" placeholder="Agent Name" value="<?php echo e(old('agent_name')); ?>">
  </div>


  <div class="form-row">
    <div class="form-group col-md-12">
         <label for="agent_contact">Agent Contact</label>
         <input type="number" name="agent_contact" class="form-control <?php echo e($errors->has('agent_contact') ? ' is-invalid' : 'Phone Number is invalid'); ?>" id="agent_contact" placeholder="9809876543"  value="<?php echo e(old('agent_phone')); ?>" autocomplete="off">

           <?php if($errors->has('agent_contact')): ?>
           <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('agent_contact')); ?></strong>
            </span>
            <?php endif; ?>
       </div>
    </div>

   <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputEmail4"> Email</label>
          <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" placeholder="rk@gmail123.com" name="email"   value="<?php echo e(old('email')); ?>">

           <?php if($errors->has('email')): ?>
           <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
      </div>

      <div class="form-group col-md-6">
          <label for="inputPassword4"> Password</label>
          <input type="password" class="form-control<?php echo e($errors->has('agent_email') ? ' is-invalid' : ''); ?>" id="agent_password" placeholder="Password" name="agent_password"  value="<?php echo e(old('agent_password')); ?>" >

            <?php if($errors->has('agent_password')): ?>
             <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('agent_Password')); ?></strong>
            </span>
            <?php endif; ?> 
    </div>
  </div>




      <div class="form-group">
          <label for="agent_address">Agent Address</label>
            <input type="text" name="agent_address" class="form-control<?php echo e($errors->has('agent_address') ? ' is-invalid' : ''); ?>" id="agent_address" placeholder="1234 Main St" value="<?php echo e(old('agent_address')); ?>">
               <?php if($errors->has('agent_address')): ?>
               <span class="invalid-feedback" role="alert">
               <strong><?php echo e($errors->first('agent_address')); ?></strong>
               </span>
                 <?php endif; ?>
          </div>


        <select class="browser-default custom-select" name="agent_type">
        <option selected>Choose AgentType</option>
        <option value="Regular">Regular</option>
        <option value="Part time">Part Time</option>
        <option value="Full Time">Full Time</option>
        </select><br>

  


  <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Register</button>
</form>


<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>