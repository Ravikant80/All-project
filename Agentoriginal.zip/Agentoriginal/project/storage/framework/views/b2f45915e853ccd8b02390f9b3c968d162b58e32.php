          <!DOCTYPE html>
          <html>
          <head>
          	<title>export exel sheet</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          </head>
          <body>
          </br>
          <div class="container">
              <h3 align="center"> Files Table Export  </h3><br/>
              <div class="table-responsive">
                 <table class="table table-striped  table-bordered">
                         <thead>
                           <tr>
                                <th>ClientName</th>
                                <th>ClientAddress</th>
                                <th> ClientContact</th>
                                <th>AssignAmount</th>
                                <th>DateOfAmtAssign</th>
                          </tr>

                         </thead>

                        <tbody>
                                <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr> 
                              <td><?php echo e($balances->client_name); ?></td>
                              <td><?php echo e($balances->client_address); ?></td>
                              <td><?php echo e($balances->client_contact); ?></td>
                              <td><?php echo e($balances->amount); ?></td>
                              <td><?php echo e($balances->date_of_transfer); ?></td>
                             <!--  <td><?php echo e($balances->updated_at); ?></td> -->

                                
                        </tr>  

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                    </table>
                  </div>
                </div>        
          </body>
          </html>