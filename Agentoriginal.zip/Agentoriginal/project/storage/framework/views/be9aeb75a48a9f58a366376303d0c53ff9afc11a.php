                 
          <?php $__env->startSection('contents'); ?>

          <!-- <?php if(session('message')): ?>
          <p class="alert alert-success"></p>
          <?php endif; ?> 
          -->
          <a href="<?php echo e(URL::to('downloadsExcel/xls')); ?>"><button class="btn btn-success mb-2">Download Excel xls</button></a>
          <a href="<?php echo e(URL::to('downloadsExcel/csv')); ?>"><button class="btn btn-success mb-2">Download CSV</button></a>
          <a href="<?php echo e(url ('forClientPDF')); ?>" class="btn btn-danger expbtn1 mb-2"> Download to PDF</a>
              <!-- DataTables Example -->
                   <div class="card mb-3">
                  <div class="card-header">
                  <i class="fas fa-table"></i>
                  Client Record </div>
                <div class="card-body">
              <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                    <th>No</th>
                    <th>ClientName</th>
                    <th>ClientAddress</th>
                    <th>ClientContact</th>
                    <th>ClientEmail</th>
                    <th>AgentType</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                   $i=0;
                    ?>

                  <?php if(count($clients)): ?>
                  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($client->client_name); ?></td>
                    <td ><?php echo wordwrap($client->client_address,15,"<br>\n");?></td>
                    <td><?php echo e($client->client_contact); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->client_type); ?></td>
                    <td>
                      &nbsp;<a href="<?php echo e(url('client/view-profile/'.$client->client_id )); ?>" >View</a>
                      &nbsp;<a href="<?php echo e(url('client/edit-profile/'.$client->client_id )); ?>"> Edit</a>
                        <a href="<?php echo e(url('client/delete-profile/'.$client->client_id )); ?>" onclick="return myFunction();"> Delete</a>
                    </td>
                  </tr>     
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>         
          </div>
          </div>

          <script>
          function myFunction() {
          if(!confirm("Are You Sure to delete this"))
          event.preventDefault();
          }
          </script>
          <?php $__env->stopSection(); ?>




                
                      
             

                
<?php echo $__env->make('layouts.admin_common', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>