<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Register_Agent</title>

    <!-- Bootstrap core CSS-->
    <link href="asset/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="asset/admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="asset/css/sb-admin.css" rel="stylesheet">

  </head>

  <body class="bg-dark">

    <div class="container">
      <div class="card card-register mx-auto mt-10">
        <div class="card-header">Register_Agent</div>
        <div class="card-body">

          <form action="<?php echo e(route('storeAgent')); ?>" method="post">
               <?php echo csrf_field(); ?>
            
            <div class="form-group">
              <div class="form-row">

                <div class="col-md-6">
                  <div class="form-label-group">

                    <input type="text" id="firstName" class="form-control" name="agent_id" placeholder="agent_id" required="required" autofocus="autofocus">
                    <label for="firstName">Agent_id</label>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-label-group">

                    <input type="text" id="firstName" class="form-control" name="agent_name" placeholder="agent_name" required="required" autofocus="autofocus">

                    <label for="firstName">Agent_Name</label>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="lastName" class="form-control" name="agent_address" placeholder="agent_address" required="required">
                    
                    <label for="lastName">Agent_Address</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputEmail" class="form-control" placeholder="agent_contact" required="required">
                <label for="inputEmail">Agent_Contact</label>
              </div>
            </div>

            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="inputPassword" class="form-control" placeholder="agent_type" required="required">
                    <label for="inputPassword">Agent_Type</label>
                  </div>
                </div>
                
              </div>
            </div>
            <a class="btn btn-primary btn-block" href="login.html">Register</a>
          </form>
          <div class="text-center">
            <a class="d-block small mt-3" href="login.html">Login Page</a>
            <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="asset/admin/vendor/jquery/jquery.min.js"></script>
    <script src="asset/admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="asset/admin/vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>
