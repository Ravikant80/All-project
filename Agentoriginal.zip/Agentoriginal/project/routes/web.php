/<?php
//use App\User;
//use Notification;
//use App\Notifications\DatabseNotification;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

	Route::get('/', function () {

	 return view('welcome');
	 });


	 // Auth::routes();

	 //  Route::get('/home', 'HomeController@index')->name('home');

								
						/*Admin Route
#############################################################################
*/

     //Route::get('admin-dashboard',['as'=>'admin-dashboard','uses'=>'Admin\ADashboardController@index']);

		 Route::get('ADshboard',['as'=>'ADshboard','uses'=>'Admin\ADashboardController@index']);
		 Route::get('admin/login','Admin\LoginController@showLoginForm');
		 Route::post('admin.login','Admin\LoginController@login');
		 Route::get('admin/register','Admin\RegisterController@registerForm')->name('admin.register');
		 Route::post('admin/register','Admin\RegisterController@create');
		 Route::get('admin/logout', 'Admin\LoginController@logout');
		 Route::post('admin-password/email','ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
		 Route::get('admin-password/reset','ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');

		//Reset Password

		Route::get('admin-password/reset{token}','Admin\ResetPasswordController@showResetForm')->name('admin.password.reset');
		Route::post('admin-password/reset','Admin\ResetPasswordController@reset');

		//Agent Login
		Route::get('agent_login','Admin\Agent\AgentLoginController@showLoginForm');
		Route::post('agent_login','Admin\Agent\AgentLoginController@loginuser');
		Route::get('agent-dashboard','Admin\Agent\AgentLoginController@getAgentDashboard');
		Route::get('showclient','Admin\Agent\AgentLoginController@showMoney');
		Route::get('agent/logout', 'Admin\Agent\AgentLoginController@logout');
		

		//Agent Record
		Route::get('/agent/add','Admin\Agent\AgentController@regAgentForm');
		Route::post('/agent/store','Admin\Agent\AgentController@storeAgent');
		Route::get('agent/show',['as'=>'agent/show','uses'=>'Admin\Agent\AgentController@showAgent']);
		Route::get('agent/view-profile/{id}','Admin\Agent\AgentController@viewAgent');
		Route::get('agent/edit-profile/{id}',['as'=>'agent.edit-profile','uses'=>'Admin\Agent\AgentController@editAgent']);
		Route::post('agent/update-profile/{id}',['as'=>'agent.update-profile','uses'=>'Admin\Agent\AgentController@updateAgent']);
		Route::get('agent/delete-profile/{id}',['as'=>'agent.delete-profile','uses'=>'Admin\Agent\AgentController@destroyAgent']);


		//client
		Route::get('/client/add','Admin\Client\ClientController@regClientForm');
		Route::post('/client/store','Admin\Client\ClientController@storeClient');
		Route::get('client/show',['as'=>'client/show','uses'=>'Admin\Client\ClientController@showClient']);
		Route::get('client/view-profile/{id}','Admin\Client\ClientController@viewClient');
		Route::post('client/update-profile/{id}',['as'=>'client.update-profile','uses'=>'Admin\Client\ClientController@updateClient']);
		Route::get('client/edit-profile/{id}',['as'=>'client.edit-profile','uses'=>'Admin\Client\ClientController@editClient']);
		Route::get('client/delete-profile/{id}',['as'=>'client.delete-profile','uses'=>'Admin\Client\ClientController@destroyClient']);
		//get client and agent data
		Route::get('getclientagentdata',['as'=>'getclientagentdata','uses'=>'Admin\ADashboardController@getClientAgentData']);
		Route::post('clientagentstore',['as'=>'clientagentstore','uses'=>'Admin\ADashboardController@clientagentStore']);
		Route::get('assignclient/delete-profile/{id}',['as'=>'assignclient.delete-profile','uses'=>'Admin\ADashboardController@destroyAssignData']);

		//Assign Amount
		Route::get('amttransfer',['as'=>'amttransfer','uses'=>'Admin\ADashboardController@ClientAgentData']);
		Route::post('amtstore',['as'=>'amtstore','uses'=>'Admin\ADashboardController@amtStore']);
		Route::get('amount/delete-profile/{id}',['as'=>'amount.delete-profile','uses'=>'Admin\ADashboardController@destroyAmt']);


		

		// Excel and pdf for clients and Agent
		Route::get('client/Pdf','Admin\Client\ClientController@downloadPDF');
		Route::get('client/exports_excel', 'Admin\Client\ClientController@index');
		Route::get('client/downloadsExcel/{type}', 'Admin\Client\ClientController@export');

		Route::get('agent/downloadPDF','Admin\Agent\AgentController@downloadPDF');
		Route::get('agent/export_excel', 'Admin\Agent\AgentController@index');	
		Route::get('agent/downloadExcel/{type}', 'Admin\Agent\AgentController@export');
		Route::get('agent/showmoney_excel/{type}', 'Admin\Agent\AgentLoginController@export');
		Route::get('agent/showMoneyPDF','Admin\Agent\AgentLoginController@downloadPDF');

		Route::get('admin/assignmoney_pdf','Admin\ADashboardController@assignMoneyPDF');
		Route::get('admin/assignmoney_excel/{type}', 'Admin\ADashboardController@export');
		//AgentStatus Maintain
		Route::get('agent/receive_money/{id}', 'Admin\Agent\AgentLoginController@amtReceive');
		Route::get('agent/reject_money/{id}', 'Admin\Agent\AgentLoginController@amtPending');

		




