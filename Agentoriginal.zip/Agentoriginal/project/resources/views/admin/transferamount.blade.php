@extends('layouts.admin_common')       
  @section('contents')
  <ol class="breadcrumb">
    <li class="breadcrumb-item">
      <a href="{{ url ('amttransfer') }}">TransferAmount</a>
        </li>
          <li class="breadcrumb-item active">Client & Agent</li>
        </ol>

    <div class="container">
      <form method="post" action="{{ url ('amtstore') }}">
                    @csrf
               <div class="form-group">
                  <div class="row"></div>
                    <label for="sel2"><b>SelectClient</b></label>
                      <select multiple class="form-control" id="sel2" name="client_id" required="">
          	           @foreach ($client as $clients)
           		         <option value="{{ $clients->client_id }}" >{{ $clients->client_name }}</option>
                        @endforeach	
                    </select>

                        <div class="form-group">
         	                <label for="sel2" class="mt-4"><b>SelectAgent</b></label>
          	               <select multiple class="form-control mt-2" id="sel3" name="agent_id" required="">
                             @foreach ($agent as $agents)
                              <option value="{{ $agents->agent_id }}" >{{ $agents->agent_name }}</option>
                              @endforeach
                            </select>
                        </div>
                              

                             
                        <div class="form-group col-md-4">
                        <label for="amount"> AssignAmount:</label>
                       <input type="text" id="text145"name="amount"class="form-control {{ $errors->has('amount') ? ' is-invalid' : 'Phone Number is invalid' }}" placeholder="OnlyNumber" value="{{ old('amount') }}" >
                        @if ($errors->has('amount'))
                          <span class="invalid-feedback" role="alert">
                          <strong>{{ $errors->first('amount') }}</strong>
                          </span>
                        @endif       
                       </div>
          

            <center> <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Assign</button></center>
                     <!-- <button type = "submit" value = "Clic" onclick = "getConfirmation();" />
                                                                                                 -->    
      </form>
   </div>

      <div class="alert alert-success fade in">
      <a href="{{ url ('clientagentstore') }}" class="close" data-dismiss="alert">&times;</a>
      <strong>Success!</strong> Successfully Assign.
      </div>

    
  
      <!--Pdf and Excel Button-->

      <a href="{{ URL::to('admin/assignmoney_excel/xls') }}"><button type="button" class="btn btn-outline-warning mb-2 mr-2">Download Excel xls</button></a>
      <a href="{{ url ('admin/assignmoney_pdf') }}"><button type="button" class="btn btn-outline-danger mb-2">Download to PDF</button></a>

        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Amount Assign Record </div>
           <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <?php
                  $i=0;
                  ?>
                  <tr>
                    <th>No</th>
                    <th>AgentName</th>
                    <th>ClientName</th>
                    <th>AssignAmt</th>
                    <th>AssignDate</th>
                    <!-- <th>ReceiveDate</th> -->
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  @foreach($amount as $amounts)
                  <tr>
                    <td>{{++$i}}</td> 
                    <td>{{$amounts->agent_name}}</td>
                    <td>{{$amounts->client_name}}</td>
                    <td>{{$amounts->amount}}</td>
                    <td>{{$amounts->date_of_transfer}}</td>

                   <!--  <td>{{$amounts->updated_at}}</td> -->
                    <td>
                    @if($amounts->status === 1)
                    <a href=""class="btn btn-primary btn-sm active">Recieve</a>
                    @elseif($amounts->status === 2)
                    <a href=""class="btn btn-danger btn-sm active">Reject</a>
                    @else
                    <a href=""class="btn btn-primary btn-sm active">pending</a>
                    @endif  
                  </td>

                    <td>
                      <a href="{{ url('amount/delete-profile/'.$amounts->id )}}" onclick="return myFunction();" class ="btn btn-primary "> Delete</a> 

                    </td>
                    </tr>     
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>         
          </div>
        </div>

    <script>
    function myFunction(){
      if(!confirm("!! Are You Sure Delete AgentName And ClientName"))
      event.preventDefault();
      }
    </script>

    
@endsection
