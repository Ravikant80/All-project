@extends('layouts.agent_common')       
  @section('contents')

<a href="{{ URL::to('agent/showmoney_excel/xls') }}"><button type="button" class="btn btn-outline-warning mb-2 mr-2">Download Excel xls</button></a>
<a href="{{ url ('agent/showMoneyPDF') }}"><button type="button" class="btn btn-outline-danger mb-2">Download to PDF</button></a>

<div class="card mb-3">
  <div class="card-header">
  <i class="fas fa-table"></i>

     <center> 

        <h5 style="color:#008080;"> 
         Hi 
         {{$data->agent_name}}
          You Need To Collect Money 
          <h5>

      </center>
          </div>
              <div class="card-body">
                <div class="table-responsive">
   

        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <thead>
                  <tr>
                  <th>ClientName</th>
                  <th>ClientAddress</th>
                  <th> ClientContact</th>
                  <th>AssignAmount</th>
                  <th>DateOfAmtAssign</th>
                  <!--  <th>updated_at</th> -->
                  <th>Status</th>
                  <th>Action</th>
                  </tr>
               </thead>

                <tbody>
                @foreach($balance as $balances)
                <tr> 
                    <td>{{$balances->client_name}}</td>
                    <td>{{$balances->client_address}}</td>
                    <td>{{$balances->client_contact}}</td>
                    <td>{{$balances->amount}}</td>
                    <td>{{$balances->date_of_transfer}}</td>
                   <!--  <td>{{$balances->updated_at}}</td> -->

                    <td>
                    
                    @if($balances->status === 1)
                    <a href="javascript:void(0);"  class="btn btn-primary btn-sm active">Receive</a>
                    @elseif($balances->status === 2)
                    <a href="javascript:void(0);"class="btn btn-primary btn-sm active">Reject</a>
                    @else
                    <a href="javascript:void(0);"class="btn btn-primary btn-sm active">pending</a>
                    @endif  
                      
                       
                    </td> 
                    <td>
                      @if($balances->status === 0)
                      &nbsp;<a href="{{ url('agent/receive_money/'.$balances->id )}}"  class="btn btn-primary btn-sm active">Accept</a>
                      &nbsp;<a href="{{ url('agent/reject_money/'.$balances->id )}}"  class="btn btn-danger btn-sm active">Reject</a>

                       @elseif($balances->status === 1)
                        &nbsp;<a href="javascript:void(0);"  class="btn btn-primary btn-sm active">Receive</a>
                        
                     

                       @elseif($balances->status === 2)
                        &nbsp;<a href="javascript:void(0);"  class="btn btn-danger btn-sm active">Reject</a>
                        
                        @endif

                    </td>


              </tr>
             @endforeach
          </tbody>
        </table>
      </div>
    </div>         
</div>
@endsection


