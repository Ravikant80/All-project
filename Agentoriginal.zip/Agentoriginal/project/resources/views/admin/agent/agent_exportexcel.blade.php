          <!DOCTYPE html>
          <html>
          <head>
          <title>export excel sheet</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          </head>
          <body>
          </br>
          <div class="container">
          <h3 align="center"> Files Table Export </h3><br/>
            <div class="table-responsive">
               <table class="table table-striped  table-bordered">
                       <thead>
                         <tr>
                          <th>No</th>
                          <th>AgentName</th>
                          <th>AgentEmail</th>
                          <th>AgentAddress</th>
                          <th>AgentContact</th>
                          <th>AgentType</th>
                         </tr>
                       </thead>

                      <tbody>
                        <?php
                       $i=0;
                        ?>

                        @if(count($agents))
                        @foreach($agents as $agent)
                         <tr>
                            <td>{{++$i}}</td>
                            <td>{{$agent->agent_name}}</td>
                            <td>{{$agent->email}}</td>
                             <td ><?php echo wordwrap($agent->agent_address,15,"<br>\n");?></td> 
                             <td>{{$agent->agent_address}}</td>
                            <!-- <td>{{$agent->agent_contact}}</td> -->
                            <td>{{$agent->agent_type}}</td>
                        </tr>     
                      @endforeach
                       @endif
                      </tbody>
                  </table>
                </div>
              </div>         
          </body>
          </html>