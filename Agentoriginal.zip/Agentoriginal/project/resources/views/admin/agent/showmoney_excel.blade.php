          <!DOCTYPE html>
          <html>
          <head>
          	<title>export exel sheet</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          </head>
          <body>
          </br>
          <div class="container">
              <h3 align="center"> Files Table Export  </h3><br/>
              <div class="table-responsive">
                 <table class="table table-striped  table-bordered">
                         <thead>
                              <tr>
                                <th>ClientName</th>
                                <th>ClientAddress</th>
                                <th> ClientContact</th>
                                <th>AssignAmount</th>
                                <th>DateOfAmtAssign</th>
                            </tr>

                         </thead>

                              <tbody>
                                @foreach($balance as $balances)
                              <tr>
                              <td>{{$balances->client_name}}</td>
                              <td>{{$balances->client_address}}</td>
                              <td>{{$balances->client_contact}}</td>
                              <td>{{$balances->amount}}</td>
                              <td>{{$balances->date_of_transfer}}</td>
                             <!--  <td>{{$balances->updated_at}}</td> -->

                                
                            </tr>  

                          @endforeach
                          
                        </tbody>
                    </table>
                  </div>
                </div>        
          </body>
          </html>