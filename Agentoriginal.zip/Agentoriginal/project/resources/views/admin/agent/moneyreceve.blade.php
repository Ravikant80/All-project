@extends('layouts.agent_common')       
  @section('contents')		
<div class="card mb-3">
  <div class="card-header">
  <i class="fas fa-table"></i>
    <h4> Hi 
      {{$data->agent_name}}
        Your Clients Amount Receive Details
          <h4> 
          </div>
             <div class="card-body">
                <div class="table-responsive">

    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
          <tr>
          <th>ClientName</th>
            <th>ClientAddress</th>
               <th> ClientContact</th>
               <th>AmountReceive</th>
               <th>DateOfAmtReceive</th>
                 </tr>
             </thead>

              <tbody>
                @foreach($balance as $balances)
                  <tr> 
                     <td>{{$balances->client_name}}</td>
                        <td>{{$balances->client_address}}</td>
                           <td>{{$balances->client_contact}}</td>
                             <td>{{$balances->amount}}</td>
                             <td>{{$balances->date_of_transfer}}</td>
                               </tr>     
                                @endforeach
                                                                   
                                  </tbody>
                                      </table>

                              </div>
                            </div>         
                        </div>
  		            @endsection
