<html>
  <head>
    <meta charset="utf-8">
    <title></title>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

          <!-- Bootstrap core CSS-->
          <link href="{{ asset('asset/admin/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

          <!-- Custom fonts for this template-->
          <link href="{{ asset('asset/admin/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">

          <!-- Page level plugin CSS-->
          <link href="{{ asset('asset/admin/vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">

          <!-- Custom styles for this template-->
          <link href="{{ asset('asset/css/sb-admin.css')}}" rel="stylesheet">
          <link href="{{ asset('asset/css/custome.css')}}" rel="stylesheet">

  </head>
  <body>
    <div>
     <h3>
       Agent Record
     </h3> 
    </div>
    <table class="table table-bordered">
       <thead>
                 <tr>
                  <th>No</th>
                  <th>AgentName</th>
                  <th>AgentEmail</th>
                  <th>AgentAddress</th>
                  <th>AgentContact</th>
                  <th>AgentType</th>
                 </tr>
               </thead>

              <tbody>

                @if(count($agents))
                @foreach($agents as $agent)
                 <tr>
                    <td>{{$agent->agent_id}}</td>
                    <td>{{$agent->agent_name}}</td>
                    <td>{{$agent->email}}</td>
                    <td ><?php echo wordwrap($agent->agent_address,15,"<br>\n");?></td>
                    <td>{{$agent->agent_contact}}</td>
                    <td>{{$agent->agent_type}}</td>
                    
                      @endforeach
                       @endif
                  </tbody>
              </table>  
           </body>
        </html>




    