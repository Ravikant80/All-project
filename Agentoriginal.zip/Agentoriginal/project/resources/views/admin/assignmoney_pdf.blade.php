<html>
  <head>
    <meta charset="utf-8">
    <title></title>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

          <!-- Bootstrap core CSS-->
          <link href="{{ asset('asset/admin/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

          <!-- Custom fonts for this template-->
          <link href="{{ asset('asset/admin/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">

          <!-- Page level plugin CSS-->
          <link href="{{ asset('asset/admin/vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">

          <!-- Custom styles for this template-->
          <link href="{{ asset('asset/css/sb-admin.css')}}" rel="stylesheet">
          <link href="{{ asset('asset/css/custome.css')}}" rel="stylesheet">

  </head>
  <body>
      <div>
        <h3>
        Assign Money Record
       </h3> 
    </div>
    <table class="table table-bordered">
       <thead>
        <?php
        $i=0;
        ?>
                 <tr>
                  <th>No</th>
                  <th>AgentName</th>
                  <th>ClientName</th>
                  <th>AssignAmount</th>
                  <th>DateOfAmtAssign</th>
                   <th>Status</th>
                </tr>
               
               </thead>

              <tbody>

               @foreach($balance as $balances)
                       <tr> 
                              <td>{{++$i}}</td>
                              <td>{{$balances->agent_name}}</td>
                              <td>{{$balances->client_name}}</td>
                              <td>{{$balances->amount}}</td>
                              <td>{{$balances->date_of_transfer}}</td>
                              <td>{{$balances->status}}</td>
                        </tr>     
                          @endforeach
                  </tbody>
              </table>  
           </body>
        </html>




    