      @extends('layouts.admin_common')       
        @section('contents')
<style type="text/css">
                
      a.btn:hover {
     -webkit-transform: scale(1.1);
     -moz-transform: scale(1.1);
     -o-transform: scale(1.1);
    }
 a.btn {
     -webkit-transform: scale(0.8);
     -moz-transform: scale(0.8);
     -o-transform: scale(0.8);
     -webkit-transition-duration: 0.5s;
     -moz-transition-duration: 0.5s;
     -o-transition-duration: 0.5s;
 }
</style>
        <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              client Record </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>ClientName</th>
                      <th>ClientAddress</th>
                      <th>ClientContact</th>
                      <th>ClintType</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{{$client->client_id}}</td>
                      <td>{{$client->client_name}}</td>
                      <td>{{$client->client_address}}</td>
                      <td>{{$client->client_contact}}</td>
                      <td>{{$client->client_type}}</td>
                    
                       <td>
                        <a href="{{ URL::previous('client/show') }}"class="btn btn-primary a-btn-slide-text">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        <span><strong>Go Back</strong></span>            
                        </a>
                        <a href="{{ url('client/delete-profile/'.$client->client_id )}}" onclick="return myFunction();" class="btn btn-primary a-btn-slide-text">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        <span><strong>Delete</strong></span>            
                        </a>
                      </td>  
                   </tr>     
                  </tbody>
                </table>
              </div>
            </div>         
          </div>
      </div>
  <script>
    function myFunction() {
        if(!confirm("Are You Sure to delete this"))
        event.preventDefault();
    }
   </script>
  @endsection