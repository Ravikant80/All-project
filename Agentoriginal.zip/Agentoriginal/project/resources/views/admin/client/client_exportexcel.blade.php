          <!DOCTYPE html>
          <html>
          <head>
          	<title>export excel sheet</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          </head>
            <body>
              </br>
                <div class="container">
                  <h3 align="center"> Files Table Export  </h3><br/>
                   <div class="table-responsive">
                 <table class="table table-striped  table-bordered">
                         <thead>
                           <tr>
                            <th>No</th>
                            <th>ClientName</th>
                            <th>ClientEmail</th>
                            <th>ClientAddress</th>
                            <th>ClientContact</th>
                            <th>ClientType</th>
                           </tr>
                         </thead>
                        <tbody>
                          <?php
                         $i=0;
                          ?>

                          @if(count($agents))
                          @foreach($clients as $client)
                           <tr>
                              <td>{{++$i}}</td>
                              <td>{{$client->client_name}}</td>
                              <td>{{$client->email}}</td>
                              <!-- <td ><?php echo wordwrap($agent->agent_address,15,"<br>\n");?></td> -->
                               <td>{{$client->client_address}}</td>
                              <td>{{$client->client_contact}}</td>
                              <td>{{$client->client_type}}</td>
                          </tr>     
                        @endforeach
                         @endif
                        </tbody>
                    </table>
                  </div>
                </div>        
              </body>
          </html>