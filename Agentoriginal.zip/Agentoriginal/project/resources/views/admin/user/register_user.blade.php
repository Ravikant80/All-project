    @extends('layouts.admin_common')     
    @section('contents')

     <!-- Breadcrumbs-->
              <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="#">Register</a>
              </li>
              <li class="breadcrumb-item active">User</li>
              </ol>

              @if(Session::has('message'))
                <div class="alert alert-info">
                    {{ Session::get('message') }}
                </div>
              @endif
              @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $message)
                            <li>{{ $message }}</li>
                        @endforeach
                    </ul>
                </div>
              @endif
      <form method="post" id="add_user_form_id" action=" {{ url('/user/store') }}" >
      @csrf
           <div class="form-group">
            <label for="agent_name">User Name</label>
           <input type="text" name="user_name" class="form-control" id="user_name" placeholder=" Name" value="{{ old('user_name') }}">
        </div>


      <div class="form-row">
        <div class="form-group col-md-12">
             <label for="agent_contact">User Contact</label>
             <input type="number" name="user_contact" class="form-control {{ $errors->has('user_contact') ? ' is-invalid' : 'Phone Number is invalid' }}" id="user_contact" placeholder="9809876543"  value="{{ old('user_contact') }}" autocomplete="off">

               @if ($errors->has('user_contact'))
               <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('user_contact') }}</strong>
                </span>
                @endif
           </div>
        </div>

       <div class="form-row">
            <div class="form-group col-md-6">
              <label for="inputEmail4"> Email</label>
              <input type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" id="email" placeholder="rk@gmail123.com" name="email"   value="{{ old('email') }}">

               @if ($errors->has('email'))
               <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('email') }}</strong>
                </span>
                @endif
          </div>

             <div class="form-group col-md-6">
              <label for="inputPassword4"> Password</label>
              <input type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" id="agent_password" placeholder="Password" name="password"  value="{{ old('password') }}" >

                @if ($errors->has('password'))
                 <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('Password') }}</strong>
                </span>
                @endif 
              </div>
                </div>

          <div class="form-group">
              <label for="agent_address">User Address</label>
                <input type="text" name="user_address" class="form-control{{ $errors->has('user_address') ? ' is-invalid' : '' }}" id="user_address" placeholder="1234 Main St" value="{{ old('user_address') }}">
                   @if ($errors->has('user_address'))
                   <span class="invalid-feedback" role="alert">
                   <strong>{{ $errors->first('user_address') }}</strong>
                   </span>
                     @endif
                </div>
          <!--       
            <select class="browser-default custom-select" name="agent_type">
            <option selected>Choose AgentType</option>
            <option value="Regular">Regular</option>
            <option value="Part time">Part Time</option>
            <option value="Full Time">Full Time</option>
            </select><br> -->
      <button type="submit" id="submit_btn" class="btn btn-primary mt-4">Register</button>
    </form>
    @endsection


