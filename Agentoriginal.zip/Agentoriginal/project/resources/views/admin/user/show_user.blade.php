          @extends('layouts.admin_common')       
          @section('contents')

          <!-- @if(session('message'))
          <p class="alert alert-success"></p>
          @endif 
          -->
          <a href="{{ URL::to('downloadsExcel/xls') }}"><button class="btn btn-success mb-2">Download Excel xls</button></a>
          <a href="{{ URL::to('downloadsExcel/csv') }}"><button class="btn btn-success mb-2">Download CSV</button></a>
          <a href="{{ url ('forClientPDF') }}" class="btn btn-danger expbtn1 mb-2"> Download to PDF</a>
              <!-- DataTables Example -->
                   <div class="card mb-3">
                  <div class="card-header">
                  <i class="fas fa-table"></i>
                  User Record </div>
                <div class="card-body">
              <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                    <th>No</th>
                    <th>UserName</th>
                    <th>UserAddress</th>
                    <th>UserContact</th>
                    <th>Email</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                   $i=0;
                    ?>

                  @if(count($users))
                  @foreach($users as $user)
                  <tr>
                    <td>{{++$i}}</td>
                    <td>{{$user->user_name}}</td>
                    <td ><?php echo wordwrap($user->user_address,15,"<br>\n");?></td>
                    <td>{{$user->user_contact}}</td>
                    <td>{{$user->email}}</td>
                    <td>
                      &nbsp;<a href="{{ url('user/view-profile/'.$user->id )}}" >View</a>
                      &nbsp;<a href="{{ url('user/edit-profile/'.$user->id )}}"> Edit</a>
                            <a href="{{ url('user/delete-profile/'.$user->id )}}" onclick="return myFunction();"> Delete</a>
                    </td>
                  </tr>     
                 @endforeach
                  @endif
                </tbody>
              </table>
            </div>
          </div>         
          </div>
          </div>

          <script>
          function myFunction() {
          if(!confirm("Are You Sure to delete this"))
          event.preventDefault();
          }
          </script>
          @endsection




                
                      
             

                