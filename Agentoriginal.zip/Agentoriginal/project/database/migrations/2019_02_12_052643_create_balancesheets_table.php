<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBalancesheetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('balancesheets', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('client_id');
            $table->integer('agent_id');
            $table->interger('status')->default(0);
            $table->float('amount')->unsigned()->default(0);
            $table->timestamp('date_of_transfer');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('balancesheets');
    }
}
