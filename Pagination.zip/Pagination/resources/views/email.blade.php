<!DOCTYPE html>
<html>
<head>
	<title>This is Email System</title>
</head>
<body>
<h2> Hi, This Is : {{ $name }}</h2>	
<h2>My Message For You:{{ $msg }}</h2>

<div>
   

</div>
</body>
</html>

