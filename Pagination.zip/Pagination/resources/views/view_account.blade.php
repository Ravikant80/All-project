<!DOCTYPE html>
<html>
<head>
	<title>this is onetone </title>
</head>
<body>
<!-- DataTables Example -->
          
                <table>
                  <thead>
                    <tr>
                      <th>AccountNo</th>
                   		<th>Id</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{{$account->account_number}}</td>
           				<td>{{$account->id}}</td>
                   </tr>     
                  </tbody>
                </table>
            
</body>
</html>