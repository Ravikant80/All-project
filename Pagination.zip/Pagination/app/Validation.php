<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Validation extends Model
{
    //
}
