<?php


return [
    /*
     * Exclude the cancellations from the model's queries.
     * Will apply to all, find, etc.
     */
    'exclude' => false,
];
