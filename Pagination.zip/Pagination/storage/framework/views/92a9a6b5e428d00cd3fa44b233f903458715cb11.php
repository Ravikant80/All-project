<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Our Data Here</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" />
   </head>
<body>
   <div class="container">
      <table class="table table-striped">
         <thead>
         <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Address</th>
             <th>Amount</th>
            <th>Date</th>
         </tr>
         </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($datas->id); ?></td>
               <td><?php echo e($datas->name); ?></td>
               <td><?php echo e($datas->address); ?></td>
               <td><?php echo e($datas->amount); ?></td>
               <td><?php echo e($datas->date); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
      <?php echo e($data->links()); ?>

   </div>
   </body>
</html>