<?php $__env->startSection('content'); ?>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-confirmation/1.0.5/bootstrap-confirmation.min.js"></script>


 <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>




<div class="container-fluid">
<div class="row">
<div class="col-md-12 col-md-offset-2">
<div class="panel panel-default">
<div class="panel-heading">
         <h4><font color="blue"> Uploading Multipal Image </font> <h4>
        </div>

    <div class="panel-body">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                Please correct following errors:
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('/photo')); ?>" method="post" enctype="multipart/form-data">

                <div class="form-group">
                <input type="file" name="image[]" class="form-control-file" multiple="true">
                </div>

                <?php echo e(csrf_field()); ?>


                <button type="submit" class="btn btn-primary">Upload To Server</button>
            </form>
                <hr>
                    <h3>Listing Images</h3>

                            <div class="row">
                             <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-3">
                            <?php
                             echo "<br/> <br/>";
                             ?>
                            &nbsp; &nbsp;<img src="<?php echo e($photo->thumbnail); ?>" class="img-responsive">
                            
                        </div>
                         <a href="<?php echo e(url('/deleteimg/'.$photo->id)); ?>">Delete</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No image found
                        <?php endif; ?>
                    </div>
                 </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
    $(document).ready(function () {        
        $('[data-toggle=confirmation]').confirmation({
            rootSelector: '[data-toggle=confirmation]',
            onConfirm: function (event, element) {
                element.closest('form').submit();
            }
        });   
    });
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>