<!DOCTYPE html>
<html>
<head>
	<title>This is Email System</title>
</head>
<body>
<h2> Hi, This Is : <?php echo e($name); ?></h2>	
<h2>My Message For You:<?php echo e($msg); ?></h2>

<div>
   

</div>
</body>
</html>

