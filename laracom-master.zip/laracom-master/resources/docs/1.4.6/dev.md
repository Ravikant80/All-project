# Dev Guide

# breadcumb

Breadcumb can applied generacally and specifically from controller.  example included in dashboard controller for specific breadcumb while generically is applied through `GlobalTemplateServiceProvider` provider. 
