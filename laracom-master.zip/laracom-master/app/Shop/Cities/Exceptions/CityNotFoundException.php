<?php

namespace App\Shop\Cities\Exceptions;

class CityNotFoundException extends \Exception
{
}
