<?php

namespace App\Shop\Customers\Exceptions;

class CreateCustomerInvalidArgumentException extends \Exception
{
}
