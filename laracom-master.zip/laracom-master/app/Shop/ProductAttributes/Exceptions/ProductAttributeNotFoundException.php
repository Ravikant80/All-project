<?php

namespace App\Shop\ProductAttributes\Exceptions;

class ProductAttributeNotFoundException extends \Exception
{
}
