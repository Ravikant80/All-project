<?php

namespace App\Shop\Categories\Exceptions;

class CategoryNotFoundException extends \Exception
{
}
