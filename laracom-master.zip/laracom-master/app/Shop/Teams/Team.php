<?php

namespace App\Shop\Teams;

use Laratrust\Models\LaratrustTeam;

class Team extends LaratrustTeam
{
}
