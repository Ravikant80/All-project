<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsdToCfas extends Model
{
    protected $table = 'usd_to_cfa';

    protected $guarded = [''];
}
