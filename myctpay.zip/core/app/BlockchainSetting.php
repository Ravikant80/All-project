<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlockchainSetting extends Model
{
    protected $table = 'blockchain_settings';

    protected $guarded = [''];
}
