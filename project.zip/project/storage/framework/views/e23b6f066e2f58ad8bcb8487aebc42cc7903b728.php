<?php $__env->startSection('content'); ?>

   <section class="padding-top-40 padding-bottom-60">
<div class="container">
      <?php if(session()->has('success_message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success_message')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="row">
        <div class="col-md-6">

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group ">
                            <label for="name" class=" text-md-right"><?php echo e(__('Name')); ?></label>


                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label for="email" class=" col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>


                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>

                        <div class="form-group ">
                            <label for="password" class="col-form-label text-md-right"><?php echo e(__('Password')); ?></label>


                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class=" col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>


                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                        </div>
                       
 
                        <div class="form-group">
                            <label for="gender" class=" col-form-label text-md-right"><?php echo e(__('Gender')); ?></label><br/>
                                   <div class="col-sm-3 radio-inline">
           
                                <input name="gender" id="input-gender-male"  value="Male" type="radio"  <?php echo e((old('gender') == 'Male') ? 'checked' : ''); ?> />Male
             
                                 </div>
                               <div class="col-sm-3 radio-inline">
           
                                <input name="gender" id="input-gender-female" value="Female" type="radio"  <?php echo e((old('gender') == 'Female') ? 'checked' : ''); ?>/>Female
             
                                 </div>
                               <?php if($errors->has('gender')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>
                        <br/>
                        <div class="form-group">
                            <label for="phone-number" class=" col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>


                            <input id="phone-number" type="number" class="form-control" name="phone_number" required value="<?php echo e(old('phone_number')); ?>">
                            <?php if($errors->has('phone_number')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="address" class=" col-form-label text-md-right"><?php echo e(__('Address')); ?></label>


                            <input id="address" type="text" class="form-control" name="address" required value="<?php echo e(old('address')); ?>">
                            <?php if($errors->has('address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="city" class=" col-form-label text-md-right"><?php echo e(__('City')); ?></label>


                            <input id="city" type="text" class="form-control" name="city" required value="<?php echo e(old('city')); ?>">
                            <?php if($errors->has('city')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="state" class=" col-form-label text-md-right"><?php echo e(__('State')); ?></label>


                            <input id="state" type="text" class="form-control" name="state" required value="<?php echo e(old('state')); ?>">
                            <?php if($errors->has('state')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('state')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="pincode" class=" col-form-label text-md-right"><?php echo e(__('Pincode')); ?></label>


                            <input id="pincode" type="text" class="form-control" name="pincode" required value="<?php echo e(old('pincode')); ?>">
                            <?php if($errors->has('pincode')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('pincode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-12 offset-md-4">
                                <button type="submit" class="btn btn-round">
                                    <?php echo e(__('Register')); ?>

                                </button>
                                
                            </div>
                        </div>
                        
                    </form>
            <p>Already member? <a  href="<?php echo e(route('login')); ?>">
                                        <?php echo e(__('Login')); ?>

                                </a>
            </p>

        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>