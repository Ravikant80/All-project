<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                   <div class="h1">
                   
                    </div>
                    <div class="portlet light bordered">
                     <div class="portlet-title">
                        <div class="caption font-dark">
                        </div>
                        <div class="tools"> </div>
                    </div>
                      <div class="portlet-body">
                       <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                         <thead>
                          <tr>
                            <th>SNo.</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Pincode</th>
                          </tr>
                         </thead>
                         <tbody>
                           <?php $i=0;?>
                          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $i++;?>

                           <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo e($customer->email); ?></td>
                            <td><?php echo e($customer->phone_number); ?></td>
                            <td><?php echo e($customer->address); ?></td>
                            <td><?php echo e($customer->city); ?></td>
                            <td><?php echo e($customer->state); ?></td>
                            <td><?php echo e($customer->pincode); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </tbody>
                       </table>
                       
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>








<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

   


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>