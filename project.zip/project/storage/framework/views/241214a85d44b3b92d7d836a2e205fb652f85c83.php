<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div id="content">

  <!-- Linking -->
  <div class="linking">
    <div class="container">
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li class="active">Checkout</li>
      </ol>
    </div>
  </div>

  <!-- Blog -->
  <section class="login-sec padding-top-30 padding-bottom-100">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-12">
          <!-- Login Your Account -->
          <h5>Login Registered User</h5>

          <!-- FORM -->
           <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="email" class=" text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>

                        <div class="form-group">
                            <label for="password" class=" text-md-right"><?php echo e(__('Password')); ?></label>


                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>
                        <div class="form-group">
                            <?php if(Request::has('previous')): ?>
                                <input type="hidden" name="previous" value="<?php echo e(Request::get('previous')); ?>">
                            <?php else: ?>
                                <input type="hidden" name="previous" value="<?php echo e(URL::previous()); ?>">
                            <?php endif; ?>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-12 offset-md-4">
                                <button type="submit" class="btn btn-round">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                 <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-round" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                     </a>
                                 <?php endif; ?>
                                
                            
                                
                            </div>
                        </div>
                        
                    </form>
          <p> not a member ?  <a  href="<?php echo e(route('register') . '?previous=' . Request::fullUrl()); ?>">
                                        <?php echo e(__('Register')); ?>

                                </a>
                </p>
        </div>
       

      </div>
      </div>

        <div class="col-md-6">
          <h5>Order Summary</h5>
          <section class="shopping-cart">

              <table class="table">

                <tbody>
                  <?php $cartdata = Cart::getContent();?>
                  <?php $__currentLoopData = $cartdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdatas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $pdata =getPoductDetails($cartdatas->id);  ?>
                  <!-- Item Cart -->
                  <tr>
                    <td>
                      <div class="media">
                        <div class="media-left"> <a href="#."> <img class="img-responsive" src="<?php echo e(asset('ecommerce/assets/admin/upload/catalog/images/'.$pdata->image)); ?>" alt="" > </a>
                        </div>

                      </div>
                    </td>
                    <td>
                    <div class="media-body">
                      <p><?php echo e($cartdatas->name); ?></p>
                      <p>Sub Total :Rs <?php echo e(Cart::get($cartdatas->id)->getPriceSum()); ?></p>
                      <p>Quantity : <?php echo e($cartdatas->quantity); ?></p>
                    </div>
                  </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
              </table>

              <!-- Promotion -->
              <div class="promo">


                <!-- Grand total -->
                <div class="g-totel">
                  <h5> Grand Total: <span>Rs <?php echo e(Cart::getTotal()); ?></span></h5>
                </div>
              </div>


          </section>

        </div>
      </div>
    </div>
  </section>




</div>
<!-- End Content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>