
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                  
                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <strong><i class="fa fa-line-chart bold uppercase"></i> Category Details</strong>
                            </div>

                            <div class="tools">
                               
                            </div>
                        </div>
                        <div class="portlet-body">
                        <table class="table table-striped table-bordered">
                        
                         <tbody>
                         
                           <tr><td>Product Name</td><td><?php echo e($product->name); ?></td></tr>
                           <tr><td>Product Category</td><td><?php echo e($product->product_category); ?></td></tr>
                           <tr><td>Product Short Description</td><td><?php echo e($product->short_description); ?></td></tr>
                           <tr><td>Product Description</td><td><?php echo e($product->description); ?></td></tr>
                           <tr><td>Product Price</td><td><?php echo e($product->price); ?></td></tr>
                           
                           
                         
                         </tbody>
                       </table> 
                       <a href="<?php echo e(url('admin/product/delete/'.$product->id)); ?>" class="btn green">Delete</a> 
                        <a href="<?php echo e(url('admin/product')); ?>" class="btn btn-default">Cancel</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   






<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('assets/admin/js/jquery.waypoints.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.counterup.min.js')); ?>" type="text/javascript"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>