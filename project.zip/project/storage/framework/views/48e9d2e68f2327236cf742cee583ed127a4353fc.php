<!doctype html>
<html class="no-js" lang="en">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="M_Adnan" />
<!-- Document Title -->
<title>Ecommerce</title>

<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">

<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/rs-plugin/css/settings.css')); ?>" media="screen" />

<!-- StyleSheets -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

<!-- Fonts Online -->
<link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

 <?php echo $__env->yieldPushContent('styles'); ?>
<!-- JavaScripts -->
<script src="<?php echo e(asset('assets/js/vendors/modernizr.js')); ?>"></script>

</head>
<body>

<!-- Page Wrapper -->
<div id="wrap" class="layout-1"> 

  <!-- Top bar -->
  <?php echo $__env->make("layouts.menu", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
 <!-- Header -->
  <?php echo $__env->make("layouts.nav", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- END Header -->
  
  <!-- Slid Sec -->
 <?php echo $__env->yieldContent('content'); ?>
  <!-- End Content --> 
  
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 
  <!-- Rights -->
  <div class="rights">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <p>Copyright © 2017 <a href="#." class="ri-li"> Ecommerce </a>HTML5 template. All rights reserved</p>
        </div>
        <div class="col-sm-6 text-right"> <img src="<?php echo e(asset('assets/images/card-icon.png')); ?>" alt=""> </div>
      </div>
    </div>
  </div>
  
  <!-- End Footer --> 
  
  <!-- GO TO TOP  --> 
  <a href="#" class="cd-top"><i class="fa fa-angle-up"></i></a> 
  <!-- GO TO TOP End --> 
</div>
<!-- End Page Wrapper --> 

<!-- JavaScripts --> 
<script src="<?php echo e(asset('assets/js/vendors/jquery/jquery.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/vendors/wow.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/vendors/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/vendors/own-menu.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/vendors/jquery.sticky.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/vendors/owl.carousel.min.js')); ?>"></script> 

<!-- SLIDER REVOLUTION 4.x SCRIPTS  --> 
<script type="text/javascript" src="<?php echo e(asset('assets/rs-plugin/js/jquery.tp.t.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/rs-plugin/js/jquery.tp.min.js')); ?>"></script> 
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
 <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

<!-- Mirrored from event-theme.com/themes/html/smarttech/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Jan 2019 04:40:29 GMT -->
</html>