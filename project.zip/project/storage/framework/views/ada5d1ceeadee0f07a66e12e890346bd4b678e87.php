<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <div class="product">
              <article>
                <a href="<?php echo e(url('/product/'.str_slug($products->product_category).'/'.str_slug($products->name))); ?>">
                <img class="img-responsive" src="<?php echo e(asset('ecommerce/assets/admin/upload/catalog/images/'.$products->image)); ?>" alt="" height="243px">
              </a>
             
                <span class="tag"><?php echo e($products->product_category); ?></span> <a href="<?php echo e(url('/product/'.str_slug($products->product_category).'/'.str_slug($products->name))); ?>" class="tittle"><?php echo e($products->name); ?></a>
                <!-- Reviews -->
                  <p class="rev">
                      <span class="margin-left-10 rating">4.0<i class="fa fa-star"></i></span>
                       <span class="rating-user">(75)</span>
                       <?php if($products->discount): ?>
                      <span class="discount_class"><?php echo e($products->discount); ?>% Off</span>
                      <?php endif; ?>
                      
                  </p>
                  <div class="price"><?php echo e($products->price); ?> </div>
                <a href="<?php echo e(url('addToCart/p/'.$products->id)); ?>" class="cart-btn"><i class="icon-basket-loaded"></i></a> </article>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

