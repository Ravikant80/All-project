
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <strong><i class="fa fa-line-chart bold uppercase"></i> Create Product </strong>
                            </div>

                            <div class="tools">
                                <a href="javascript:;" class="collapse"> </a>
                            </div>

                        </div>
                    </div>

                            <form method="post" action="<?php echo e(url('admin/product-store')); ?>">

                                <div class="card mt-3 mb-3">

                                    <div class="card-body">

                                      <div class="form-group">
                                        <label class="control-label visible-ie8 visible-ie9">Product Name :</label>
                                        <input class="form-control form-control-solid placeholder-no-fix" type="text" value="<?php echo e(old('name')); ?>" autocomplete="off" placeholder="Category Name" name="name" />
                                       </div>

                                        <div class="form-group">
                                          <label class="control-label visible-ie8 visible-ie9">Product Category</label>
                                           <select class="form-control " name="product_category" label="Product Category"  >
                                             <?php if(count($category)==0): ?>
                                             <option>Simple Product</option>
                                             <?php else: ?>
                                             <option>Simple Product</option>
                                             <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option><?php echo e($categories->name); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php endif; ?>

                                           </select>

                                         </div>


                                    </div>
                                </div>



                                  <div class="form-actions">
                                            <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn green"><i class="fa fa-sign-in"></i> Create & Continue</button>
                                     <a href="<?php echo e(url('admin/product')); ?>" class="btn btn-default">Cancel</a>
                                  </div>

                            </form>

                </div>
            </div>
        </div>
    </div>








<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('assets/admin/js/jquery.waypoints.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.counterup.min.js')); ?>" type="text/javascript"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>