<div class="top-bar">
    <div class="container">
      <p>Welcome to ETW Shopping Mall!</p>
      <div class="right-sec">
        <ul>
          <?php if(Auth::check()): ?>
          <li><a href="#">Hi. <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret-down"></i></a>
              <ul class="sub-menu">
                  <li><a href="<?php echo e(url('user/my-account')); ?>">My Account</a></li>
                  <li>
                      <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();" class="">Log Out</a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                      </form>
                  </li>
              </ul>
          </li>
          <?php else: ?>

            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>

          <?php endif; ?>
          
          <!-- <li><a href="<?php echo e(route('login')); ?>">Login/Register </a></li> -->
          <li><a href="<?php echo e(url('/')); ?>">Store Location </a></li>
          <li><a href="<?php echo e(url('/')); ?>">FAQ </a></li>
          <li><a href="<?php echo e(url('/')); ?>">Newsletter </a></li>
          <!-- <li>
            <select class="selectpicker">
              <option>French</option>
              <option>German</option>
              <option>Italian</option>
              <option>Japanese</option>
            </select>
          </li> -->
          <!-- <li>
            <select class="selectpicker">
              <option>(USD)Dollar</option>
              <option>GBP</option>
              <option>Euro</option>
              <option>JPY</option>
            </select>
          </li> -->
        </ul>
        <div class="social-top"> <a href="#."><i class="fa fa-facebook"></i></a> <a href="#."><i class="fa fa-twitter"></i></a> <a href="#."><i class="fa fa-linkedin"></i></a> <a href="#."><i class="fa fa-dribbble"></i></a> <a href="#."><i class="fa fa-pinterest"></i></a> </div>
      </div>
    </div>
  </div>
