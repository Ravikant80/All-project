<!-- Newslatter -->
<!-- <section class="newslatter">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h3>Subscribe our Newsletter <span>Get <strong>25% Off</strong> first purchase!</span></h3>
      </div>
      <div class="col-md-6">
        <form>
          <input type="email" placeholder="Your email address here...">
          <button type="submit">Subscribe!</button>
        </form>
      </div>
    </div>
  </div>
</section> -->
<footer>
    <div class="container">

      <!-- Footer Upside Links -->
      <div class="foot-link">
     
      </div>
      <div class="row">

        <!-- Contact -->
        <div class="col-md-4">
          <h4> Etw Shopping Mall!</h4>
          <p>Address: 45 Grand Central Terminal Etawah,
            Uttar Pradesh India</p>
          <p>Phone: (+91) 7055662266, 7055661166</p>
          <p>Email: useretw@gmail.com</p>
          <div class="social-links"> <a href="#."><i class="fa fa-facebook"></i></a> <a href="#."><i class="fa fa-twitter"></i></a> <a href="#."><i class="fa fa-linkedin"></i></a> <a href="#."><i class="fa fa-pinterest"></i></a> <a href="#."><i class="fa fa-instagram"></i></a> <a href="#."><i class="fa fa-google"></i></a> </div>
        </div>

        <!-- Categories -->
        <div class="col-md-4">
          <h4>Our Policy</h4>
          <ul class="links-footer">
            <li><a href="{{url('return_policy')}}">Return</a></li>
            <li><a href="{{url('terms_condition')}}">Terms & Condition</a></li>
            <li><a href="{{url('security')}}">Security</a></li>
            <li><a href="{{url('privacy_policy')}}">Privacy</a></li>

            <li><a href="{{url('sitemap')}}">Sitemap</a></li>

          </ul>
        </div>

     

        <!-- Categories -->
        <div class="col-md-4">
          <h4>Information Section</h4>
          <ul class="links-footer">
            <li><a href="{{url('blog')}}">Our Blog</a></li>
            <li><a href="{{url('about_us')}}">About Our Shop</a></li>

            <li><a href="{{url('contact_us')}}">Contact Us</a></li>
            <li><a href="{{url('faq')}}">FAQs</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

