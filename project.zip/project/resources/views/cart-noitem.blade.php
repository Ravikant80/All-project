@extends('layouts.frontend')
@push('styles')

@endpush

@section('content')

<h1>No Item  </h1>
@endsection
@push('scripts')

@endpush
