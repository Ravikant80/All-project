<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryFilters extends Model
{
    //
}
