<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ValidationController extends Controller
{
   public function validation()
    {
      return view('validation');
    }
      
  
    public function validationPost(Request $request)
    {
       
    }

    public function validationPostcasda(Request $request)
    {
       
    }

	

}
