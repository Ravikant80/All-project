<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/','FrontEnd\FrontEndController@index');



//************************************************** Director Area ************************************************

Route::get('director-dashboard',['as'=>'director-dashboard-dashboard','uses'=>'Director\DirectorController@index']);
Route::get('director','Director\LoginController@showLoginForm')->name('director.login');
Route::post('director','Director\LoginController@login')->name('director.login.post');
Route::get('director/register','Director\RegisterController@registerForm')->name('director.register');
Route::post('director/register','Director\RegisterController@create');
Route::get('director/logout', 'Director\LoginController@logout');

Route::post('director-password/email','Director\ForgotPasswordController@sendResetLinkEmail')->name('director.password.email');
Route::get('director-password/reset','Director\ForgotPasswordController@showLinkRequestForm')->name('director.password.request');

//Reset Password

Route::get('admin-password/reset{token}','Admin\ResetPasswordController@showResetForm')->name('admin.password.reset');
Route::post('admin-password/reset','Admin\ResetPasswordController@reset');

Route::group(['prefix' => 'director'], function () {
Route::get('admin-register',['as'=>'admin-register','uses'=>'Director\DirectorController@getAdminRegisterForm']);
Route::post('admin-register-store',['as'=>'admin-register-store','uses'=>'Director\DirectorController@storeAdminRegisterForm']);
Route::get('admins','Director\DirectorController@getAdmin');
Route::get('delete-admin','Director\DirectorController@deleteAdmin');
Route::get('permission','Director\DirectorController@getPermission');
Route::get('permission/{id}','Director\DirectorController@viewPermission');
Route::any('setpermission','Director\DirectorController@setPermission');
});

//******************************************Admin Area****************************************************************
Route::get('admin','Director\Admin\LoginController@showLoginForm')->name('admin.login');
Route::post('admin','Director\Admin\LoginController@login')->name('admin.login.post');
Route::get('admin-dashboard','Director\Admin\AdminController@index');
Route::get('admin/logout', 'Director\Admin\LoginController@logout');

Route::group(['prefix' => 'admin'], function () {
Route::get('hod-register','Director\Admin\AdminController@getHodRegisterForm');
Route::post('hod-register-store','Director\Admin\AdminController@storeHodRegisterForm');

Route::get('add-department','Director\Admin\AdminController@addDepartment');
Route::post('store-department','Director\Admin\AdminController@storeDepartment');
Route::get('get-department','Director\Admin\AdminController@getDepartment');
Route::get('edit-department/{id}','Director\Admin\AdminController@editDepartment');
Route::post('update-department/{id}','Director\Admin\AdminController@updateDepartment');
Route::get('destroy-department/{id}','Director\Admin\AdminController@destroyDepartment');

Route::get('hods','Director\Admin\AdminController@getHod');
Route::get('consultant-register','Director\Admin\AdminController@getConsultantRegisterForm');
Route::post('consultant-register-store','Director\Admin\AdminController@storeConsultantRegisterForm');
Route::get('consultants','Director\Admin\AdminController@getConsultant');

});


//****************************************** Hod Area *******************************************************************

Route::get('hod-dashboard',['as'=>'hod-dashboard','uses'=>'Director\Admin\Hod\HodController@index']);
Route::get('hod','Director\Admin\Hod\LoginController@showLoginForm')->name('hod.login');
Route::post('hod','Director\Admin\Hod\LoginController@login')->name('hod.login.post');
Route::get('hod/logout', 'Director\Admin\Hod\LoginController@logout');




Route::group(['prefix' => 'hod'], function () {
Route::get('consultant-register','Director\Admin\Hod\HodController@getConsultantRegisterForm');
Route::post('consultant-register-store','Director\Admin\Hod\HodController@storeConsultantRegisterForm');
Route::get('consultants','Director\Admin\Hod\HodController@getConsultant');
Route::get('add-demand','Director\Admin\Hod\HodController@addDemand');
Route::post('store-demand','Director\Admin\Hod\HodController@storeDemand');
Route::get('assingn-pa','Director\Admin\Hod\HodController@assignPa');
Route::post('store-assign-pa','Director\Admin\Hod\HodController@storeAssignPa');
Route::get('get-assign-pa','Director\Admin\Hod\HodController@getAssignPa');
//imaport and export file
Route::get('importExport', 'Director\Admin\Hod\HodController@importExport');
Route::get('downloadExcel/{type}', 'Director\Admin\Hod\HodController@downloadExcel');
Route::post('importExcel', 'Director\Admin\Hod\HodController@importExcel');

});



//****************************************** Consultant Area *******************************************************************
Route::get('consultant-dashboard',['as'=>'consultant-dashboard','uses'=>'Director\Admin\Hod\Consultant\ConsultantController@index']);
Route::get('consultant','Director\Admin\Hod\Consultant\LoginController@showLoginForm')->name('consultant.login');
Route::post('consultant','Director\Admin\Hod\Consultant\LoginController@login')->name('consultant.login.post');
Route::get('consultant/logout', 'Director\Admin\Hod\Consultant\LoginController@logout');



