<html>
<head>
<style>
body  {
  background-image: url("{{asset('assets/images/logo/foody.png')}}");
  background-color: #cccccc;
  

}
</style>
</head>
<body>
<h2>sfsdfsadfsd</h2>>
</body>
</html>