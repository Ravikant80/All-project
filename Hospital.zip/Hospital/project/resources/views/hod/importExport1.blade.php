@extends('hod.hod_dashbord.dashboard')
@section('style')
<link href="{{ asset('assets/admin/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
    <style type="text/css">
        
        #heading3 {
  color: green;
}
    </style>

@endsection
@section('content')
<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> {{ $page_title }}</strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

               
    <div class="form-body">
<div class="row">
                          
    <div class="container">
        <div class="panel panel-default">
          <div class="panel-heading">
          <h3 id="heading3">Import Export to Excel and CSV </h3>
          </div>
          <div class="panel-body">
 
            <!-- <a href="{{ url('hod/downloadExcel/xls') }}"><button class="btn btn-danger">Download Excel xls</button></a> -->
            <a href="{{ url('hod/downloadExcel/xlsx') }}"><button class="btn btn-info">Download Excel xlsx</button></a>
            <a href="{{ url('hod/downloadExcel/csv') }}"><button class="btn btn-warning">Download CSV</button></a>
 
            <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="{{ url('hod/importExcel') }}" class="form-horizontal" method="post" enctype="multipart/form-data">
                @csrf
 
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
 
                @if (Session::has('success'))
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <p>{{ Session::get('success') }}</p>
                    </div>
                @endif
 
                <input type="file" name="import_file" />
                <button class="btn btn-primary" style=" 
                margin-top: 5px;
                ">
                Import File
            </button>

            </form>
 
          </div>
        </div>
    </div>
                            
                        </div>
            
            </div>
        </div>
    </div>
</div>

@endsection
