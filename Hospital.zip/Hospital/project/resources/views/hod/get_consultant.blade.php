@extends('hod.hod_dashbord.dashboard')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Reg By</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>

                    <tbody>
                    @php $i=0;@endphp
                    @foreach($consultants as $consultant)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $consultant->id}}</td>
                            <td>{{ $consultant->name}}</td>
                            <td>{{ $consultant->email}}</td>
                            @if(!empty($consultant->reg_by_admin_id))
                            <?php $admin = getAdminNameById($consultant->reg_by_admin_id);?>
                            <td><?php echo "Admin : "; 
                              echo $admin['name']; 
                             // echo Non_StdPA;?></td>
                            @elseif(!empty($consultant->reg_by_hod_id))

                            <?php $hod = getHodNameById($consultant->reg_by_hod_id);?>

                            <td><?php echo "Hod : ";
                                echo $hod['hod_name'];

                            ?></td>

                            @endif
                            
                            <td><a href="#">Edit</a></td>
                            <td><a href="#">Delete</a></td> 
                        </tr>          
                    @endforeach

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
@endsection

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>