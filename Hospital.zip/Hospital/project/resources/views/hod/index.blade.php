@extends('hod_dashboard.dashboard')

@section('content')

<h2>Contant Here</h2>                          
                            
@endsection

