@extends('hod.hod_dashbord.dashboard')
@section('style')
<link href="{{ asset('assets/admin/css/bootstrap-toggle.min.css') }}" rel="stylesheet">

@endsection
@section('content')

<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> {{ $page_title }}</strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

                <form method="post" id="add_restaurent_form_id" action=" {{ url('hod/store-assign-pa') }}"  enctype="multipart/form-data">
                    @csrf
                    <div class="form-body">
                        <div class="row">

                               <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                         <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Select Consultant:</label>
                                         </div>
                                         <div class="col-md-4">

                                            <select  name="consultant_id" class="form-control{{ $errors->has('consultant_id') ? ' is-invalid' : '' }}" required >
                                                <option value='' selected='true'>Select Consultant </option>
                                                  @foreach($consultants as $consultant)
                                                  
                                                   <option value='{{$consultant->id}}' > {{$consultant->name}} </option>

                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>   
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Specialty On Call:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="nameconstjobp_specialty_on_call_id" name="constjobp_specialty_on_call" class="form-control{{ $errors->has('constjobp_specialty_on_call') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_specialty_on_call') }}" min="0" />
                                            @if ($errors->has('constjobp_specialty_on_call'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_specialty_on_call') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Gim On Call:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="constjobp_gim_on_call_id" name="constjobp_gim_on_call" class="form-control{{ $errors->has('constjobp_gim_on_call') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_gim_on_call') }}" min="0" />
                                            @if ($errors->has('constjobp_gim_on_call'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_gim_on_call') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Out Patient:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="constjobp_outpatient_id" name="constjobp_outpatient" class="form-control{{ $errors->has('constjobp_outpatient') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_outpatient') }}" min="0" />
                                            @if ($errors->has('constjobp_outpatient'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_outpatient') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Procedure:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="constjobp_procedure_id" name="constjobp_procedure" class="form-control{{ $errors->has('constjobp_procedure') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_procedure') }}" min="0" />
                                            @if ($errors->has('constjobp_procedure'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_procedure') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Adminstration:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="constjobp_adminstration_id" name="constjobp_adminstration" class="form-control{{ $errors->has('constjobp_adminstration') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_adminstration') }}" min="0" />
                                            @if ($errors->has('constjobp_adminstration'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_adminstration') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Board Round:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="constjobp_board_round_id" name="constjobp_board_round" class="form-control{{ $errors->has('constjobp_board_round') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_board_round') }}" min="0" />
                                            @if ($errors->has('constjobp_board_round'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_board_round') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Ward Round:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_ward_round_id" name="constjobp_ward_round" class="form-control{{ $errors->has('constjobp_ward_round') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_ward_round') }}" />
                                            @if ($errors->has('constjobp_ward_round'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_ward_round') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Amu In Reach:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_amu_in_reach_id" name="constjobp_amu_in_reach" class="form-control{{ $errors->has('constjobp_amu_in_reach') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_amu_in_reach') }}" />
                                            @if ($errors->has('constjobp_amu_in_reach'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_amu_in_reach') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Ward Referral:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_ward_referral_id" name="constjobp_ward_referral" class="form-control{{ $errors->has('constjobp_ward_referral') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_ward_referral') }}" />
                                            @if ($errors->has('constjobp_ward_referral'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_ward_referral') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">GPOD:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_gpoad_id" name="constjobp_gpoad" class="form-control{{ $errors->has('constjobp_gpoad') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_gpoad') }}" />
                                            @if ($errors->has('constjobp_gpoad'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_gpoad') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">MDT:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_mdt_id" name="constjobp_mdt" class="form-control{{ $errors->has('constjobp_mdt') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_mdt') }}" />
                                            @if ($errors->has('constjobp_gpoad'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_mdt') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

  							<div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Prospective Cover:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_prospective_cover_id" name="constjobp_prospective_cover" class="form-control{{ $errors->has('constjobp_prospective_cover') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_prospective_cover') }}" />
                                            @if ($errors->has('constjobp_prospective_cover'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_prospective_cover') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                           
                           <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Research And Audit:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_research_and_audit_id" name="constjobp_research_and_audit" class="form-control{{ $errors->has('constjobp_research_and_audit') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_research_and_audit') }}" />
                                            @if ($errors->has('constjobp_research_and_audit'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_research_and_audit') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

							<div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Teaching:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_teaching_id" name="constjobp_teaching" class="form-control{{ $errors->has('constjobp_teaching') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_teaching') }}" />
                                            @if ($errors->has('constjobp_teaching'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_teaching') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Leadership And Management:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_leadership_and_management_id" name="constjobp_leadership_and_management" class="form-control{{ $errors->has('constjobp_leadership_and_management') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_leadership_and_management') }}" />
                                            @if ($errors->has('constjobp_leadership_and_management'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_leadership_and_management') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

							<div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">SPA:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0"id="constjobp_spa_id" name="constjobp_spa" class="form-control{{ $errors->has('constjobp_spa') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_spa') }}" />
                                            @if ($errors->has('constjobp_spa'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_spa') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Non Crictical Activity:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" min="0" id="constjobp_non_crictical_activity_id" name="constjobp_non_crictical_activity" class="form-control{{ $errors->has('constjobp_non_crictical_activity') ? ' is-invalid' : '' }}" required  value="{{ old('constjobp_non_crictical_activity') }}" />
                                            @if ($errors->has('constjobp_non_crictical_activity'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('constjobp_non_crictical_activity') }}</strong>
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-md-12">
                            <div class="form-group">
                              <div class="row">
                                <div class="col-md-12">
                                    <center>  <button class="btn btn-primary btn-block btn-lg" style="width: auto;"><i class="fa fa-send"></i>save</button></center>
                                </div>
                             </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
