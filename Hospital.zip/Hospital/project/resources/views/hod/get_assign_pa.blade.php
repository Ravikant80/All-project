@extends('hod.hod_dashbord.dashboard')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Specialty On Call</th>
                        <th>Gim On Call</th>
                        <th>Out Patient</th>
                        <th>Procedure</th>
                        <th>Adminstration</th>
                        <th>Board Round</th>
                        <th>Ward Round</th>
                        <th>Amu In Reach</th>
                        <th>Ward Referral</th>
                        <th>GPOD</th>
                        <th>MDT</th>
                        <th>Prospective Cover</th>
                        <th>Research And Audit</th>
                        <th>Teaching</th>
                        <th>Leadership And Management</th>
                        <th>SPA</th>
                        <th>Non Crictical Activity</th>
                        <th>Edit </th>
                        <th>Delete </th>
                    </tr>
                    </thead>

                    <tbody>
                    @php $i=0;@endphp
                    @foreach($jobplans as $jobplan)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $jobplan->id}}</td>                                                       
                            <td>{{ $jobplan->constjobp_specialty_on_call}}</td>
                            <td>{{ $jobplan->constjobp_gim_on_call}}</td>
                            <td>{{ $jobplan->constjobp_outpatient}}</td>
                            <td>{{ $jobplan->constjobp_procedure}}</td>
                            <td>{{ $jobplan->constjobp_adminstration}}</td>
                            <td>{{ $jobplan->constjobp_board_round}}</td>
                            <td>{{ $jobplan->constjobp_ward_round}}</td>
                            <td>{{ $jobplan->constjobp_amu_in_reach}}</td>
                            <td>{{ $jobplan->constjobp_ward_referral}}</td>
                            <td>{{ $jobplan->constjobp_gpoad}}</td>
                            <td>{{ $jobplan->constjobp_mdt}}</td>
                            <td>{{ $jobplan->constjobp_prospective_cover}}</td>
                            <td>{{ $jobplan->constjobp_research_and_audit}}</td>
                            <td>{{ $jobplan->constjobp_teaching}}</td>
                            <td>{{ $jobplan->constjobp_leadership_and_management}}</td>
                            <td>{{ $jobplan->constjobp_spa}}</td>
                            <td>{{ $jobplan->constjobp_non_crictical_activity}}</td>
                            <td><a href="#">Edit</a></td>
                            <td><a href="#">Delete</a></td> 
                        </tr>          
                    @endforeach

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
@endsection

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>






 