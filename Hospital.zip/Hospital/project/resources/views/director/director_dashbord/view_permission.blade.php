@extends('director.director_dashbord.dashboard')
@section('style')

<link href="{{ asset('assets/admin/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
@endsection
@section('content')
 <form action="{{url('director/setpermission')}}" method="post">
        @csrf
    <input type="hidden" name="user_id"  value="{{$admin->id}}">
    <input type="hidden" name="user_type"  value="{{$admin->user_type}}">
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                    </tr>
                    </thead>

                    <tbody>
                    
                        <tr>
                            
                            <td>{{$admin->name}}</td>
                            <td>{{$admin->email}}</td>
                        </tr>          
                  

                    </tbody>
                </table>
                 @if(!empty($permisson))
                <div class="text-center">
                     <table class="table table-striped table-bordered table-hover" >

                    <thead>
                    <tr>
                        <th>Files.</th>
                        <th>Read</th>
                        <th>Write</th>
                        <th>All</th>
                        <th>Hide</th>
                       
                    </tr>
                    </thead>
                   
                    <tbody>
                            
                        <input type="hidden" name="permisson_id" value="{{$permisson->permisson_id}}">
                        <tr>
                            <td>Hod</td>
                            <td><input type="radio" name="hod"  value="1" <?php if($permisson->hod==1){ echo "checked";}?>></td>
                            <td><input type="radio" name="hod"  value="2" <?php if($permisson->hod==2){ echo "checked";}?>></td>
                            <td><input type="radio" name="hod"  value="3"  <?php if($permisson->hod==3){ echo "checked";}?>></td>
                            <td><input type="radio" name="hod"  value="4" <?php if($permisson->hod==4){ echo "checked";}?>></td>
                        </tr>
                        <tr>
                            <td>Consultant</td>
                            <td><input type="radio" name="consultant"  value="1" <?php if($permisson->consultant==1){ echo "checked";}?>></td>
                            <td><input type="radio" name="consultant"  value="2" <?php if($permisson->consultant==2){ echo "checked";}?>></td>
                            <td><input type="radio" name="consultant"  value="3" <?php if($permisson->consultant==3){ echo "checked";}?>></td>
                            <td><input type="radio" name="consultant"  value="4" <?php if($permisson->consultant==4){ echo "checked";}?>></td>
                        </tr> 
                        <tr>
                            <td>Department</td>
                            <td><input type="radio" name="department"  value="1" <?php if($permisson->department==1){ echo "checked";}?>></td>
                            <td><input type="radio" name="department"  value="2" <?php if($permisson->department==2){ echo "checked";}?>></td>
                            <td><input type="radio" name="department"  value="3" <?php if($permisson->department==3){ echo "checked";}?>></td>
                            <td><input type="radio" name="department"  value="4" <?php if($permisson->department==4){ echo "checked";}?>></td>
                        </tr>        
                    </tbody>
                </table>
                </div>
                @else

                <div class="text-center">
                     <table class="table table-striped table-bordered table-hover" >

                    <thead>
                    <tr>
                        <th>Files.</th>
                        <th>Read</th>
                        <th>Write</th>
                        <th>All</th>
                        <th>Hide</th>
                       
                    </tr>
                    </thead>

                    <tbody>
                       
                        <tr>
                            <td>Hod</td>
                            <td><input type="radio" name="hod"  value="1" ></td>
                            <td><input type="radio" name="hod"  value="2" ></td>
                            <td><input type="radio" name="hod"  value="3" checked></td>
                            <td><input type="radio" name="hod"  value="4" ></td>
                        </tr>
                        <tr>
                            <td>Consultant</td>
                            <td><input type="radio" name="consultant"  value="1" ></td>
                            <td><input type="radio" name="consultant"  value="2" ></td>
                            <td><input type="radio" name="consultant"  value="3" checked></td>
                            <td><input type="radio" name="consultant"  value="4" ></td>
                        </tr> 
                        <tr>
                            <td>Department</td>
                            <td><input type="radio" name="department"  value="1" ></td>
                            <td><input type="radio" name="department"  value="2" ></td>
                            <td><input type="radio" name="department"  value="3" checked></td>
                            <td><input type="radio" name="department"  value="4" ></td>
                        </tr>        
                    </tbody>
                </table>
                </div>
                @endif
            </div>
        </div>

    </div>
</div>

<input type="submit" name="Submit" class="form-group">
</form>

@endsection


