@extends('director.director_dashbord.dashboard')
@section('style')

<link href="{{ asset('assets/admin/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
@endsection
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Set Permission</th>
                        
                    </tr>
                    </thead>

                    <tbody>
                    @php $i=0;@endphp
                    @foreach($admins as $admin)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $admin->id}}</td>
                            <td>{{ $admin->name}}</td>
                            <td>{{ $admin->email}}</td>
                            <td><a href="{{url('director/permission/'.$admin->id)}}" >Click</a></td> 
                        </tr>          
                    @endforeach
                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>

@endsection


