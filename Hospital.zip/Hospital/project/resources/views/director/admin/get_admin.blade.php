@extends('director.director_dashbord.dashboard')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Edit Admin</th>
                        <th> Delete Admin</th>
                    </tr>
                    </thead>

                    <tbody>
                    @php $i=0;@endphp
                    @foreach($admins as $admin)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $admin->id}}</td>
                            <td>{{ $admin->name}}</td>
                            <td>{{ $admin->email}}</td>
                            <td><a href="#">Edit</a></td>
                            <td><a href="{{url('director/delete-admin/'.$admin->id)}}" onclick="return myFunction();">Delete</a></td> 
                        </tr>          
                    @endforeach

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
@endsection

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>