@extends('admin_dashboard.dashboard')
@section('style')

<link href="{{ asset('assets/admin/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
@endsection
@section('content')


<h2>sdflksdflksdfsdfskfdslk</h2>
@endsection
