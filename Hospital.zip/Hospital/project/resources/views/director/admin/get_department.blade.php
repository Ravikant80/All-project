@extends('admin_dashboard.dashboard')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Department Head</th>
                        <th>Edit department</th>
                        <th>Delete department</th>
                    </tr>
                    </thead>

                    <tbody>
                    @php $i=0;@endphp
                    @foreach($departments as $department)
                        @php $i++;@endphp
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $department->id}}</td>
                            <td>{{ $department->name}}</td>
                            <td>{{ $department->descriptions}}</td>
                            <td>{{ $department->hod_name}}</td>
                            <td><a href="{{url('admin/edit-department/'.$department->id)}}">Edit</a></td>
                            <td><a href="{{url('admin/destroy-department/'.$department->id)}}" onclick="return confirm('Are you sure?')">Delete</a></td>
                            
                        </tr>          
                    @endforeach

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
@endsection

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>