<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GlobalParameter extends Model
{
    use SoftDeletes;
    
    protected $table ="global_parameters";
}
