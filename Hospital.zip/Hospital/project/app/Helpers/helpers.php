<?php
use Carbon\Carbon;
use App\Admin;
use App\Hod;
use App\GlobalParameter;
use App\Department;


function getglobalParameter(){

  $global = GlobalParameter::find(1);

echo $global->Std_PA;
//define("Std_PA",$global->Std_PA);               // 1 PA made 4 standard Hours
// define("Non_StdPA",3);
// define("Con_Yr",42);
// define("Weeks_Yr",52);
// define("Days_Week",7);
// define("Min_Hour",60);
// define("Days_Yr",365);
// define("Weekends_Yr",104);

  
}

function formatDate($postDate) {

        $now = Carbon::now()->toDateTimeString();

        $diff = date_diff(date_create($now), date_create($postDate));

        $day = $diff->format("%d");

        $hour = $diff->format("%h");

        $minutes = $diff->format("%i");

        $seconds = $diff->format("%s");

        $year = $diff->format("%Y");

        if ($day < 1) {

            if ($hour < 1) {
                return $diff->format('%i Minutes ago');
            } else {
                return $diff->format('%h Hours ago');
            }
        } else {


            $dateTime = explode(" ", $postDate);
            $data = explode("-", $dateTime[0]);

            $Y = $data[0];
            $m = $data[1];
            $d = $data[2];

            $data2 = explode(":", $dateTime[1]);
            $H = $data2[0];
            $i = $data2[1];
            $s = $data2[2];


            return date("D, d M Y", mktime($H, $i, 0, $m, $d, $Y)); //$diff->format('%d Day, %h Hours %i Minutes');
        }
}

function getAdminNameById($id){

    $admin = Admin::find($id);

    return $admin;
}    
function getHodNameById($id){

    $hod = Hod::find($id);

    return $hod;
}
function getDeptName(){

    $hodId = Auth::guard('hod')->user()->id;

    $data = Hod::join('departments','departments.dept_head','=','hods.id')
                                ->select('hods.*','departments.*')
                                ->where('hods.id',$hodId)
                                ->get();
    return $data;
                        
} 




    
    
    ?>
    