<?php

namespace App\Http\Controllers\Director\Admin\Hod\Consultant;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\ConsultantJobPlan;



class ConsultantController extends Controller
{
    public function __construct() {
   	$this->middleware('auth:consultant');

    }

    public function index() {

	$data['page_title']='Consultan Job Plan';
	$consultantId = Auth::guard('consultant')->user()->id;

	$data['consultants'] = ConsultantJobPlan::join('consultants','consultants.id','=','consultant_job_plans.consultant_id')
                        	->select('consultants.name', 'consultant_job_plans.*')
							->where('consultants.id',$consultantId)
                        	->get();
							return view ('consultant.consultant_dashboard.index',$data);
       
   	}

  

    

}

