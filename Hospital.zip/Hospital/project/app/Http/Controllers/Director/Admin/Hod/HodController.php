<?php

namespace App\Http\Controllers\Director\Admin\Hod;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Notification;
use Session;
use Alert;
use Auth;
use App\Hod;
use App\Consultant;
use App\Department;
use App\ConsultantJobPlan;
use DB;
use Excel;

class HodController extends Controller {

public function __construct() {
    $this->middleware('auth:hod');
}

public function index() {
    $data['page_title'] = 'Your Department';
    return view('hod.hod_dashbord.index', $data);
}

public function getConsultant() {
    $data['page_title'] = 'Consultant List';
    $data['consultants'] = Consultant::all();
    return view('hod.get_Consultant', $data);
}

public function getConsultantRegisterForm() {

    $data['page_title'] = 'Consultant Register';
    return view('hod.consultant_register', $data);
}

public function storeConsultantRegisterForm(Request $request) {

    $this->validate($request, [
            'name' => 'required',
            'email' => 'required|string| email|max:255',
            'password' => 'required|min:8',
        ]);


    $hodId = Auth::guard('hod')->user()->id;
    $const = new Consultant;
    $const->name = $request->name;
    $const->email = $request->email;
    $const->password = $request->password;
    $const->password = Hash::make($request->password);
    $const->remember_token = $request->_token;
    $const->reg_by_hod_id = $hodId;
    $const->save();
    return redirect('/hod-dashboard')->with('message', 'Consultant successfully register!!!!');
    }


    public function addDemand() {
    $data['page_title'] = 'Add Demand';
    return view('hod.add_demand',$data);
    }


    public function storeDemand(Request $request){
    }

    public function assignPa() {

    $data['page_title'] = 'Assign Pa';
    $data['consultants'] = Consultant::all();
    return view('hod.assign_pa', $data);
    }

    public function storeAssignPa(Request $request) {


         $this->validate($request, [
            'constjobp_specialty_on_call' => 'required',
            'constjobp_outpatient' => 'required',
            'constjobp_procedure' => 'required',
            'constjobp_adminstration' => 'required',
            'constjobp_amu_in_reach' => 'required',
            'constjobp_ward_referral' => 'required',
            'constjobp_gpoad' => 'required',
            'constjobp_mdt' => 'required',
            'constjobp_prospective_cover' => 'required',
            'constjobp_research_and_audit' => 'required',
            'constjobp_teaching' => 'required',
            'constjobp_leadership_and_management' => 'required',
            'constjobp_spa' => 'required',
            'constjobp_non_crictical_activity' => 'required',
             ]);


            $jobplan = new ConsultantJobPlan;
            $jobplan->consultant_id = $request->consultant_id;
            $jobplan->constjobp_gim_on_call = $request->constjobp_gim_on_call;
            $jobplan->constjobp_specialty_on_call = $request->constjobp_specialty_on_call;
            $jobplan->constjobp_outpatient = $request->constjobp_outpatient;
            $jobplan->constjobp_procedure = $request->constjobp_procedure;
            $jobplan->constjobp_adminstration = $request->constjobp_adminstration;
            $jobplan->constjobp_board_round = $request->constjobp_board_round;
            $jobplan->constjobp_ward_round = $request->constjobp_ward_round;
            $jobplan->constjobp_amu_in_reach = $request->constjobp_amu_in_reach;
            $jobplan->constjobp_ward_referral = $request->constjobp_ward_referral;
            $jobplan->constjobp_gpoad = $request->constjobp_gpoad;
            $jobplan->constjobp_mdt = $request->constjobp_mdt;
            $jobplan->constjobp_prospective_cover = $request->constjobp_prospective_cover;
            $jobplan->constjobp_research_and_audit = $request->constjobp_research_and_audit;
            $jobplan->constjobp_teaching = $request->constjobp_teaching;
            $jobplan->constjobp_leadership_and_management = $request->constjobp_leadership_and_management;
            $jobplan->constjobp_spa = $request->constjobp_spa;
            $jobplan->constjobp_non_crictical_activity = $request->constjobp_non_crictical_activity;
            $jobplan->save();
            return redirect('/hod-dashboard')->with('message', 'PA Assign Successfully !!!!');
             }

            public function getAssignPa() {
            $data['page_title'] = 'PA List';
            $data['jobplans'] = ConsultantJobPlan::all();
            return view('hod.get_assign_pa', $data);
            }

            public function importExport()
            {
                $data['page_title'] = 'importExport';
                
                return view('hod.importExport',$data);
            }
 
    
            public function downloadExcel($type)
            {
                $data = ConsultantJobPlan::get()->toArray();
                    
                return Excel::create('consultants_job_plan', function($excel) use ($data) {
                    $excel->sheet('mySheet', function($sheet) use ($data)
                    {
                        $sheet->fromArray($data);
                    });
                })->download($type);

              //  return Excel::download($data, 'const.xlsx');
            }

            public function importExcel(Request $request)
            {
                $request->validate([
                    'import_file' => 'required'
                ]);
         
                $path = $request->file('import_file')->getRealPath();
                $data = Excel::load($path)->get();
         
        if($data->count()){
            foreach ($data as $key => $value) {
                $arr[] = [
                    'consultant_id' => $value->consultant_id,
                    'constjobp_specialty_on_call' => $value->constjobp_specialty_on_call,
                    'constjobp_gim_on_call' => $value->constjobp_gim_on_call,
                    'constjobp_outpatient' => $value->constjobp_outpatient,
                    'constjobp_procedure' => $value->constjobp_procedure,
                    'constjobp_adminstration' => $value->constjobp_adminstration,
                    'constjobp_board_round' => $value->constjobp_board_round,
                    'constjobp_ward_round' => $value->constjobp_ward_round,
                    'constjobp_amu_in_reach' => $value->constjobp_amu_in_reach,
                    'constjobp_ward_referral' => $value->constjobp_ward_referral,
                    'constjobp_gpoad' => $value->constjobp_gpoad,
                    'constjobp_mdt' => $value->constjobp_mdt,
                    'constjobp_prospective_cover' => $value->constjobp_prospective_cover,
                    'constjobp_research_and_audit' => $value->constjobp_research_and_audit,
                    'constjobp_teaching' => $value->constjobp_teaching,
                    'constjobp_leadership_and_management' => $value->constjobp_leadership_and_management,
                    'constjobp_spa' => $value->constjobp_spa,
                    'constjobp_non_crictical_activity' => $value->constjobp_non_crictical_activity,
                    



             ];
            }
 
            if(!empty($arr)){
                ConsultantJobPlan::insert($arr);
            }
        }
 
        return back()->with('success', 'Insert Record successfully.');
    }

}


           