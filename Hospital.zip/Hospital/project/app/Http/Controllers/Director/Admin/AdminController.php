<?php

namespace App\Http\Controllers\Director\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Hod;
use App\Consultant;
use App\Department;
use App\ConsultantJobPlan;
use App\Demand;
use Auth;
use Redirect;

class AdminController extends Controller {

        public function __construct() {

        $this->middleware('auth:admin');
        }

        public function index() {

        $data['page_title'] = 'Admin Dashboard';
        return view('admin_dashboard.index', $data);
        }

        public function getHod() {

        $data['page_title'] = 'Hod List';
        $data['hods'] = Hod::all();
        return view('director.admin.get_hod', $data);
        }

        public function getHodRegisterForm() {

        $data['page_title'] = 'Hod Register';
        return view('director.admin.hod_register', $data);
        }

        public function storeHodRegisterForm(Request $request) {

        $this->validate($request, [
            'name' => 'required',
            'role_type' => 'required',
            'email' => 'required|string| email|max:255',
            'password' => 'required|min:8',
        ]);


        $adminId = Auth::guard('admin')->user()->id;

        $hod = new Hod;
        $hod->hod_name = $request->hod_name;
        $hod->role_type = $request->role_type;
        $hod->email = $request->email;
        $hod->password = $request->password;
        $hod->password = Hash::make($request->password);
        $hod->remember_token = $request->_token;
        $hod->reg_by_admin_id = $adminId;
        $hod->save();
        return redirect('admin/hods')->with('message', 'hod successfully register!!!!');
        
        }

        public function getConsultant() {

        $data['page_title'] = 'Consultant List';
        $data['consultants']  = ConsultantJobPlan::join('consultants','consultants.id','=','consultant_job_plans.consultant_id')
                                ->select('consultants.name', 'consultants.email','consultants.id', 'consultant_job_plans.*')
                                ->get();
        //column sum
        $data['sum_on_call'] = ConsultantJobPlan::sum('constjobp_specialty_on_call');
        $data['sum_gim_on_call'] = ConsultantJobPlan::sum('constjobp_gim_on_call');
        $data['sum_outpatient'] = ConsultantJobPlan::sum('constjobp_outpatient');
        $data['sum_procedure'] = ConsultantJobPlan::sum('constjobp_procedure');
        $data['sum_job_adm'] = ConsultantJobPlan::sum('constjobp_adminstration');
        $data['sum_board_around'] = ConsultantJobPlan::sum('constjobp_board_round');
        $data['sum_ward_around'] = ConsultantJobPlan::sum('constjobp_ward_round');
        $data['sum_amu_in_reach'] = ConsultantJobPlan::sum('constjobp_amu_in_reach');
        $data['sum_ward_refferal'] = ConsultantJobPlan::sum('constjobp_ward_referral');
        $data['sum_gproad'] = ConsultantJobPlan::sum('constjobp_gpoad');
        $data['sum_mdt'] = ConsultantJobPlan::sum('constjobp_mdt');
        $data['sum_prospective_cover'] = ConsultantJobPlan::sum('constjobp_prospective_cover');
        $data['sum_research_audit'] = ConsultantJobPlan::sum('constjobp_research_and_audit');
        $data['sum_teaching'] = ConsultantJobPlan::sum('constjobp_teaching');
        $data['sum_leadership_nd_mgmt'] = ConsultantJobPlan::sum('constjobp_leadership_and_management');
        $data['sum_spa'] = ConsultantJobPlan::sum('constjobp_spa');
        $data['sum_n_critical_activity'] = ConsultantJobPlan::sum('constjobp_non_crictical_activity');
        
        return view('director.admin.get_consultant', $data);
        }

        public function getConsultantRegisterForm() {
        
        $data['page_title'] = 'Consultant Register';
        return view('director.admin.consultant_register', $data);
        }

        public function storeConsultantRegisterForm(Request $request) {

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|string| email|max:255',
            'password' => 'required|min:8',
        ]);


        $adminId = Auth::guard('admin')->user()->id;
        $const = new Consultant;
        $const->name = $request->name;
        $const->email = $request->email;
        $const->password = $request->password;
        $const->password = Hash::make($request->password);
        $const->remember_token = $request->_token;
        $const->reg_by_admin_id = $adminId;
        $const->save();
        return redirect('admin/consultants')->with('message', 'Consultant successfully register!!!!');
        }

        public function getDepartment() {

            $data['page_title'] = 'Department List';
            $data['departments']  = Department::join('hods','hods.id','=','departments.dept_head')
                                    ->select('hods.hod_name','departments.*')
                                    ->get();

        return view('director.admin.get_department', $data);
        }
    
        public function addDepartment() {

        $data['page_title'] = 'Add Department';
        $data['hods'] = Hod::all();
        return view('director.admin.add_department', $data);
        }

        public function storeDepartment(Request $request) {
       
        $this->validate($request, [
            'name' => 'required',
            'descriptions' => 'required',
            ]);


        $dept = new Department;
        $dept->name = $request->name;
        $dept->descriptions = $request->descriptions;
        $dept->dept_head = $request->hod_id;
        $dept->save();
        return redirect('/admin-dashboard')->with('message', 'Department successfully added!!!!');
        }

        public function editDepartment(Request $request,$id) {
       
        $data['page_title'] = "Edit Department";
        $data['hods'] = Hod::all();
        $data['department']=Department::findOrFail($id);
        return view('director.admin.edit_department', $data);
        }


        public function updateDepartment(Request $request, $id) {
        
        $this->validate($request,[
            'name'=>'required', 
            'descriptions'=>'required',
            'hod_id'=>'required',
            ]);

        Department::where('id',$id)
           ->update([
            'name'=> $request->name,
            'descriptions'=>$request->descriptions,
            'dept_head'=>$request->hod_id,
            //'dept_head' =>implode(',',$request->hod_id),             
            
            ]);
        return redirect('admin/get-department')->with('message','successfully updated');
        }

        public function destroyDepartment($id) {
        
        $department=Department::find($id);
        $department->delete();
        return Redirect::back()->with('message','successfully deleted');
        }



    

}
