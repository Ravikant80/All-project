<?php

namespace App\Http\Controllers\Director;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Director;
use App\Admin;
use App\Permisson;
use Notification;
use Session;
use Alert;
use Auth;
use Redirect;


class DirectorController extends Controller {

        public function __construct() {
            
        $this->middleware('auth:director');

        }

        public function index() {

        $data['page_title'] = 'Director Dashboard';
        return view('director.director_dashbord.index', $data);

        }

        public function getAdmin() {

        $data['page_title'] = 'Admin List';
        $data['admins'] = Admin::all();
        return view('director.admin.get_admin', $data);

        }

        public function deleteAdmin($id) {

        $admin = Admin::find($id);
        $admin->delete();
        return redirect('director/admins')->with('message', 'admin successfully deleted!!!!');

        }

        public function getAdminRegisterForm() {

        $data['page_title'] = 'Admin Register';
        return view('director.admin.admin_register', $data);

        }

        public function storeAdminRegisterForm(Request $request) {

        $this->validate($request, [
        'name' => 'required',
        'email' => 'required|string| email|max:255',
        'password' => 'required|min:8',

        ]);

        $admin = new Admin;
        $admin->name = $request->name;
        $admin->email = $request->email;
        $admin->password = $request->password;
        $admin->password = Hash::make($request->password);
        $admin->remember_token = $request->_token;
        $admin->save();
        return redirect('director/admins')->with('message', 'admin successfully register!!!!');

        }

        public function getPermission() {

        $data['page_title'] = "Admins File Permission";
        $data['admins'] = Admin::all();
        return view('director.director_dashbord.permission',$data);

        }
       
        public function viewPermission($id) {

        $data['page_title'] = "Admins File Permission";
        $data['admin'] = Admin::find($id);
        $data['permisson']  = Admin::join('permissons','permissons.user_id','=','admins.id')
                                ->where('admins.id',$id)
                                ->select('admins.*','permissons.hod','permissons.consultant','permissons.department','permissons.id as permisson_id')
                                ->first();

        return view('director.director_dashbord.view_permission',$data);

        }


        public function setPermission(Request $request) {

                $this->validate($request, [

                'user_id'    => 'required',
                'hod'        => 'required',
                'consultant' => 'required',
                'department' => 'required',

                ]);


        if(isset($request->permisson_id)) {

        Permisson::where('id',$request->permisson_id)->where('user_id',$request->user_id)
        
        ->update([

                'user_id'=> $request->user_id,
                'user_type'=> $request->user_type,
                'hod'=> $request->hod,
                'consultant'=> $request->consultant,
                'department'=> $request->department,

                ]);

                }

                else {

                $permission = new Permisson;
                $permission->user_id = $request->user_id;
                $permission->user_type = $request->user_type;
                $permission->hod = $request->hod;
                $permission->consultant = $request->consultant;
                $permission->department = $request->department;
                $permission->save();

                }

                return redirect()->back();

         }

}
