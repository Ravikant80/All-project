<?php

namespace App\Http\Middleware;

use Closure;

class RedirectIfConsultant
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'consultant')
    {
        if (Auth::guard($guard)->check()) {
            return redirect('/consultant-dashboard');
        }

        return $next($request);
    }
}
