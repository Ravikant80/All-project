<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;



class CreateDemandsTable extends Migration
{
    /**
     * Run the migrations
     *
     * @return void     
     */
    public function up()
    {
        Schema::create('demands', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->String('contribute_gimrota');
            $table->String('gimno_consultant_contribute');
            $table->String('speciality_oncall_rate');
            $table->String('speciality_no_of_consulting_contributing');
            $table->String('speciality_no_of_pa_allocation');
            $table->String('outpatient_first_appoint_contribute_activity');
            $table->String('outpatient_follow_up_appointment_contribute_activity');
            $table->String('outpatient_clinic_utilization_rate_contribute_activity');
            $table->String('outpatient_adam_per_session_duration');
            $table->integer('department_id');
            $table->timestamps();
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('demands');
    }
}
