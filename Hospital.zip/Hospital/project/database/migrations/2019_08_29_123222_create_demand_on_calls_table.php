<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDemandOnCallsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('demand_on_calls', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('department_id');
            $table->integer('demand_id')->nullable();
            $table->string('onc_title');
            $table->string('onc_gim_rota');
            $table->string('onc_gim_consultant');
            $table->string('onc_sp_rota');
            $table->string('onc_sp_rota_consultant');
            $table->string('onc_sp_rota_allocated');
            $table->timestamps();
            $table->softDeletes();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('demand_on_calls');
    }
}
