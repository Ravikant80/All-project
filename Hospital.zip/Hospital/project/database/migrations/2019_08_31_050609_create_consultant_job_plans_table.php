<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConsultantJobPlansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('consultant_job_plans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('consult_id');
            $table->string('constjobp_specialty_on_call');
            $table->string('constjobp_gim_on_call');
            $table->string('constjobp_outpatient');
            $table->string('constjobp_procedure');
            $table->string('constjobp_adminstration');
            $table->string('constjobp_board_round');
            $table->string('constjobp_ward_round');
            $table->string('constjobp_amu_in_reach');
            $table->string('constjobp_ward_referral');
            $table->string('constjobp_gpoad');
            $table->string('constjobp_mdt');
            $table->string('constjobp_prospective_cover');
            $table->string('constjobp_research_and_audit');
            $table->string('constjobp_teaching');
            $table->string('constjobp_leadership_and_management');
            $table->string('constjobp_spa');
            $table->string('constjobp_non_crictical_activity');
            $table->timestamps();
            $table->softDeletes();
            
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('consultant_job_plans');
    }
}
