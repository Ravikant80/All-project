<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;



class CreateGlobalParametersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('global_parameters', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->Integer('Std_PA');
            $table->Integer('Non_StdPA');
            $table->Integer('Con_Yr');
            $table->Integer('Weeks_Yr');
            $table->Integer('Days_Week');
            $table->Integer('Min_Hour');
            $table->Integer('Days_Yr');
            $table->Integer('Weekends_Yr');
            $table->timestamps();
            $table->softDeletes();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('global_parameters');
    }
}


