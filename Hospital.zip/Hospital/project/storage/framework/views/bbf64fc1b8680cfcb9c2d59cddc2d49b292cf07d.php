<?php $__env->startSection('content'); ?>
<style type="text/css">
    .table-responsive {
            overflow-x: auto;
            min-height: .01%;
            width: 100%;
        }
</style>
<div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">

                    <div class="portlet box blue">
                        <div class="portlet-title">
                            <div class="caption">
                                <strong><i class="fa fa-line-chart bold uppercase"></i> Job Plans</strong>
                            </div>
                            <div class="tools">
                                <a href="javascript:;" class="collapse"> </a>
                            </div>
                        </div>
                        <div class="portlet-body" style="overflow: hidden">
                           

                           <div class="row">
    <div class="col-md-12">
                    <div class="col-md-6">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th scope="col">Consultant </th>
                              <th scope="col"> <?php echo Auth::guard('consultant')->user()->name; ?> </th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Paid PAs</td>
                              <td>12.00</td>
                            </tr>
                            <tr>
                              <td>Do you contribute to Consultant of the Week</td>

                            <td>

                            <select name="condition">
                            <option value="yes">yes</option>
                            <option value="no">no</option>
                            </select>

                            </td>

                            </tr>

                            <tr>
                              <th >Planned DCC PAs</th>
                              <td>9.39</td>
                            </tr>

                            <tr>
                            <th >Booked Mandatory SPAs</th>
                              <td>1.42</td>
                            </tr>

                            <tr>
                            <th >Booked Discretionary SPAs</th>
                               <td>1.01</td>
                            
                            </tr>

                            <tr>
                              <th >GIM Rota</th>
                              
                              <td>0.00</td>
                            </tr>

                            <tr>
                              <th>Speciality Rota</th>
                            
                              <td>1.00</td>
                            </tr>

                            <tr>
                              <th>Remaining PAs</th>
                                      
                              <td>-0.81</td>
                            </tr>

                            <tr>
                              <th >No of weeks in Year</th>
                            
                              <td>34</td>

                            </tr>

                          </tbody>
                        </table>
                    </div>


                    <div class="col-md-6">
                         <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th scope="col">Standard SPAs </th>
                              <th scope="col">1.50</th>
                              <td colspan="2"></td>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Discretionary  SPAs</td>
                              <td>1.01</td>
                              <td colspan="2">Discretionary Allocation </td>
                            </tr>

                            <tr>
                          <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <td> Research and Audit</td>
                              <td><?php echo e($consultant->constjobp_research_and_audit); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              <td>Reason </td>
                              <td>Amount </td>
                            </tr>
                            <tr>
                          <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <th >Teaching</th>
                              <td><?php echo e($consultant->constjobp_teaching); ?></td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              <td>ES</td>
                              <td>0.25</td>
                            </tr>
                            <tr>
                          <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <th>Leadership and Management</th>
                              <td><?php echo e($consultant->constjobp_leadership_and_management); ?></td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              <td>Teaching</td>
                              <td>0.25</td>
                            </tr>
                            <tr>
                          <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <th>  Admin</th>
                              <td><?php echo e($consultant->constjobp_adminstration); ?></td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              <td>Audit</td>
                              <td>0.5</td>
                            </tr>
                            
                          </tbody>
                        </table>
                    </div>
                </div>



                <div class="table-responsive">
                    <table class="table table-bordered ">
                          <thead>
                            <tr>
                              <td colspan="17">Dept MDT</td>
                              <td colspan="12">Surg MDT</td>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td rowspan="2"></td>
                              <td colspan="4">Monday</td>
                              <td colspan="4">Tuesday</td>
                              <td colspan="4">Wednesday</td>
                              <td colspan="4">Thursday</td>
                              <td colspan="4">Friday</td>
                              <td colspan="4">Saturday</td>
                              <td colspan="4">Sunday</td>
                            </tr>
                            <tr>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity1</td>
                              <td>SPA</td>
                              <td>0.750</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>SPA</td>
                              <td>0.250</td>
                              <td>Clinic</td>
                              <td>1.000</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>Cath Lab </td>
                              <td>1.000</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>Administration</td>
                              <td>0.750</td>
                              <td>Teaching</td>
                              <td>0.625</td>
                              <td>Clinic</td>
                              <td>1.000</td>
                              <td>Prospective Cover</td>
                              <td>0.250</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td>Activity2</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity3</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity4</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Total PAs</td>
                              <td></td>
                              <td>1.000 </td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                            </tr>
                            <tr>
                              <td colspan="10"> Warning! Total Activity PAs exceeds 1</td>
                              <td colspan="10">Warning! Total Activity PAs exceeds 1</td>
                              
                              <td colspan="10">Warning! Total Activity PAs exceeds 1</td>
                            </tr>
                            <tr>
                              <td > Note</td>
                              <td colspan="28"></td>
                            </tr>
                            <tr>
                              <td > COW Weeks in Year</td>
                              <td colspan="28">8</td>
                            </tr>
                            <tr>
                              <td rowspan="2"></td>
                              <td colspan="4">Monday</td>
                              <td colspan="4">Tuesday</td>
                              <td colspan="4">Wednesday</td>
                              <td colspan="4">Thursday</td>
                              <td colspan="4">Friday</td>
                              <td colspan="4">Saturday</td>
                              <td colspan="4">Sunday</td>
                            </tr>
                            <tr>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity1</td>
                              <td>SPA</td>
                              <td>0.750</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>SPA</td>
                              <td>0.250</td>
                              <td>Clinic</td>
                              <td>1.000</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>Cath Lab </td>
                              <td>1.000</td>
                              <td>Cath Lab</td>
                              <td>1.000</td>
                              <td>Administration</td>
                              <td>0.750</td>
                              <td>Teaching</td>
                              <td>0.625</td>
                              <td>Clinic</td>
                              <td>1.000</td>
                              <td>Prospective Cover</td>
                              <td>0.250</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td>Activity2</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity3</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Activity4</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                              <td>AM</td>
                              <td>PAs</td>
                              <td>PM </td>
                              <td>PAs</td>
                            </tr>
                            <tr>
                              <td>Total PAs</td>
                              <td></td>
                              <td>1.000 </td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td></td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                              <td> </td>
                              <td>2.000</td>
                            </tr>
                            <tr>
                              <td colspan="10"> Warning! Total Activity PAs exceeds 1</td>
                              <td colspan="10">Warning! Total Activity PAs exceeds 1</td>
                              
                              <td colspan="10">Warning! Total Activity PAs exceeds 1</td>
                            </tr>
                            <tr>
                              <td > Note</td>
                              <td colspan="28"></td>
                            </tr>
                            
                          </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </div>
    </div>
    </div>
</div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('consultant.consultant_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/consultant/consultant_dashboard/index.blade.php ENDPATH**/ ?>