<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                         <th>ID#</th> 
                        <th>Name</th>
                        <th>Email</th>
                        <th>WTE</th>
                        <th>Paid PA</th>
                        <th>Total PA</th>
                        <th>Specialty On Call</th>
                        <th>Gim On Call</th>
                        <th>Outpatient</th>
                        <th>Procedure</th>
                        <th>Adminstration</th>
                        <th>Board Round</th>
                        <th>Ward Round</th>
                        <th>Amu In Reach</th>
                        <th>Ward Referral</th>
                        <th>GPOD</th>
                        <th>MTD</th>
                        <th>prospective cover</th>
                        <th>Research And Audit</th>
                        <th>Teaching</th>
                        <th>Leadership And Management</th>
                        <th>SPA</th>
                        <th>Non Crictical Activity</th>
                        
                        <th>Edit Consultant</th>
                        <th>Delete Consultant</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($consultant->consultant_id); ?></td>
                            <td><?php echo e($consultant->name); ?></td>
                            <td><?php echo e($consultant->email); ?></td>
                            <td>0</td>
                            <td>0</td>
                            <td>
                                     
                                <?php  echo $consultant->constjobp_specialty_on_call+$consultant->constjobp_gim_on_call+$consultant->constjobp_outpatient+$consultant->constjobp_procedure+$consultant->constjobp_adminstration+$consultant->constjobp_board_round+$consultant->constjobp_ward_round+$consultant->constjobp_amu_in_reach+$consultant->constjobp_ward_referral+$consultant->constjobp_gpoad+$consultant->constjobp_mdt+$consultant->constjobp_prospective_cover+$consultant->constjobp_research_and_audit+$consultant->constjobp_teaching+$consultant->constjobp_leadership_and_management+$consultant->constjobp_spa+$consultant->constjobp_non_crictical_activity;?>

                            </td>
                            <td><?php echo e($consultant->constjobp_specialty_on_call); ?></td>
                            <td><?php echo e($consultant->constjobp_gim_on_call); ?></td>
                            <td><?php echo e($consultant->constjobp_outpatient); ?></td>
                            <td><?php echo e($consultant->constjobp_procedure); ?></td>
                            <td><?php echo e($consultant->constjobp_adminstration); ?></td>
                            <td><?php echo e($consultant->constjobp_board_round); ?></td>
                            <td><?php echo e($consultant->constjobp_ward_round); ?></td>
                            <td><?php echo e($consultant->constjobp_amu_in_reach); ?></td>
                            <td><?php echo e($consultant->constjobp_ward_referral); ?></td>
                            <td><?php echo e($consultant->constjobp_gpoad); ?></td>
                            <td><?php echo e($consultant->constjobp_mdt); ?></td>
                            <td><?php echo e($consultant->constjobp_prospective_cover); ?></td>
                            <td><?php echo e($consultant->constjobp_research_and_audit); ?></td>
                            <td><?php echo e($consultant->constjobp_teaching); ?></td>
                            <td><?php echo e($consultant->constjobp_leadership_and_management); ?></td>
                            <td><?php echo e($consultant->constjobp_spa); ?></td>
                            <td><?php echo e($consultant->constjobp_non_crictical_activity); ?>


                                <?php //$sum =0; $sum += $consultant->constjobp_spa;
                                       //echo $sum; ?></td>

                          
                            <td><a href="#">Edit</a></td>
                            <td><a href="#">Delete</a></td> 
                        </tr>    
                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <h5> start Specialty On Call</h5>

                <div class="text-center">
                    <table>
                        <tr>
                            <td><?php echo e($sum_on_call); ?> |</td>
                            <td><?php echo e($sum_gim_on_call); ?> |</td>
                            <td><?php echo e($sum_outpatient); ?> |</td>
                            <td><?php echo e($sum_procedure); ?> |</td>
                            <td><?php echo e($sum_job_adm); ?> |</td>
                            <td><?php echo e($sum_board_around); ?> |</td>
                            <td><?php echo e($sum_ward_around); ?> |</td>
                            <td><?php echo e($sum_amu_in_reach); ?> |</td>
                            <td><?php echo e($sum_ward_refferal); ?> |</td>
                            <td><?php echo e($sum_gproad); ?> |</td>
                            <td><?php echo e($sum_mdt); ?> |</td>
                            <td><?php echo e($sum_prospective_cover); ?> |</td>
                            <td><?php echo e($sum_research_audit); ?> |</td>
                            <td><?php echo e($sum_teaching); ?> |</td>
                            <td><?php echo e($sum_leadership_nd_mgmt); ?> |</td>
                            <td><?php echo e($sum_spa); ?> |</td>
                            <td><?php echo e($sum_n_critical_activity); ?> |</td>
                        </tr>  
                    </table>
                  
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>
<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/director/admin/get_consultant.blade.php ENDPATH**/ ?>