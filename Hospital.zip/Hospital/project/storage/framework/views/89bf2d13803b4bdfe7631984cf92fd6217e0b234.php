<html>
<head>
<style>
body  {
  background-image: url("<?php echo e(asset('assets/images/logo/foody.png')); ?>");
  background-color: #cccccc;
  

}
</style>
</head>
<body>
<h2>sfsdfsadfsd</h2>>
</body>
</html><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/welcome1.blade.php ENDPATH**/ ?>