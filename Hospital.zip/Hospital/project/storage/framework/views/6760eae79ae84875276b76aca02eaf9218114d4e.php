<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Reg By</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($consultant->id); ?></td>
                            <td><?php echo e($consultant->name); ?></td>
                            <td><?php echo e($consultant->email); ?></td>
                            <?php if(!empty($consultant->reg_by_admin_id)): ?>
                            <?php $admin = getAdminNameById($consultant->reg_by_admin_id);?>
                            <td><?php echo "Admin : "; 
                              echo $admin['name']; 
                             // echo Non_StdPA;?></td>
                            <?php elseif(!empty($consultant->reg_by_hod_id)): ?>

                            <?php $hod = getHodNameById($consultant->reg_by_hod_id);?>

                            <td><?php echo "Hod : ";
                                echo $hod['hod_name'];

                            ?></td>

                            <?php endif; ?>
                            
                            <td><a href="#">Edit</a></td>
                            <td><a href="#">Delete</a></td> 
                        </tr>          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>
<?php echo $__env->make('hod.hod_dashbord.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/hod/get_Consultant.blade.php ENDPATH**/ ?>