<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Department Head</th>
                        <th>Edit department</th>
                        <th>Delete department</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($department->id); ?></td>
                            <td><?php echo e($department->name); ?></td>
                            <td><?php echo e($department->descriptions); ?></td>
                            <td><?php echo e($department->hod_name); ?></td>
                            <td><a href="<?php echo e(url('admin/edit-department/'.$department->id)); ?>">Edit</a></td>
                            <td><a href="<?php echo e(url('admin/destroy-department/'.$department->id)); ?>" onclick="return confirm('Are you sure?')">Delete</a></td>
                            
                        </tr>          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>
<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/director/admin/get_department.blade.php ENDPATH**/ ?>