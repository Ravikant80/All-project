<html lang="en">
<head>
    <title> Import Export to Excel and CSV</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
    <style type="text/css">
        
        h1 {
  color: green;
}
    </style>
</head>
<body>
    <div class="container">
        <div class="panel panel-default">
          <div class="panel-heading">
          <h3 id="heading3">Import Export to Excel and CSV </h3>
          </div>
          <div class="panel-body">
 
            <a href="<?php echo e(url('hod/downloadExcel/xls')); ?>"><button class="btn btn-danger">Download Excel xls</button></a>
            <a href="<?php echo e(url('hod/downloadExcel/xlsx')); ?>"><button class="btn btn-info">Download Excel xlsx</button></a>
            <a href="<?php echo e(url('hod/downloadExcel/csv')); ?>"><button class="btn btn-warning">Download CSV</button></a>
 
            <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="<?php echo e(url('hod/importExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
 
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
 
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <p><?php echo e(Session::get('success')); ?></p>
                    </div>
                <?php endif; ?>
 
                <input type="file" name="import_file" />
                <button class="btn btn-primary" style=" 
                margin-top: 5px;
                ">
                Import File
            </button>

            </form>
 
          </div>
        </div>
    </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/hod/importExport.blade.php ENDPATH**/ ?>