<?php $__env->startSection('style'); ?>

<link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css" rel="stylesheet" /> -->


<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

                <form method="post" id="add_restaurent_form_id" action=" <?php echo e(url('admin/store-department')); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">


                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Hod Name:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="text" id="inputTextBox" name="hod_name" class="form-control<?php echo e($errors->has('hod_name') ? ' is-invalid' : ''); ?>" required  value="<?php echo e(old('hod_name')); ?>" />
                                        
                                        <?php if($errors->has('hod_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('hod_name')); ?></strong>
                                        </span>
                                         <?php endif; ?>


                                        </div>
                                    </div>
                                </div>
                            </div> 

                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Descriptions:</label>
                                        </div>
                                        <div class="col-md-4">

                                            <input type="text" id="descriptions" name="descriptions" class="form-control<?php echo e($errors->has('descriptions') ? ' is-invalid' : ''); ?>" required  value="<?php echo e(old('descriptions')); ?>" />

            
                                         <?php if($errors->has('descriptions')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('descriptions')); ?></strong>
                                        </span>
                                         <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div> 
                             <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                         <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Select HOD's:</label>
                                         </div>
                                         <div class="col-md-4">

                                            <select  name="hod_id" class="form-control<?php echo e($errors->has('hod_id') ? ' is-invalid' : ''); ?>" required >
                                                <option value='' selected='true'>Select Hod </option>
                                                  <?php $__currentLoopData = $hods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  
                                                   <option value='<?php echo e($hod->id); ?>' > <?php echo e($hod->hod_name); ?> </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-md-12">
                              <center>  <button class="btn btn-primary btn-block btn-lg" style="width: auto;"><i class="fa fa-send"></i> Add Departmen</button></center>
                          </div>
                      </div>
                  </div>
              </form>
          </div>
      </div>
  </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>
<script type="text/javascript">
 jQuery(document).ready(function(){
       jQuery("select").select2();
   });
</script>

<!-- validation link -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
   $.validate();
</script>
<script type="text/javascript">
    $(document).ready(function(){
    $("#inputTextBox").keypress(function(event){
        var inputValue = event.which;
        // allow letters and whitespaces only.
        if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)) { 
            event.preventDefault(); 
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital\project\resources\views/director/admin/add_department.blade.php ENDPATH**/ ?>