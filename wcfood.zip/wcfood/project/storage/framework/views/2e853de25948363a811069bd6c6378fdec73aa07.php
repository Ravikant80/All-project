<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Content -->
<div id="content">


<!--After order  admin view -->
<!-- Oder-success -->
   <section>
          <div class="container">
            <!-- Payout Method -->
             <div class="order-success"> <i class="fa fa-check"></i>
              <h6>Thank you for your order</h6>
              <p>Order number is:<?php echo e($order['id']); ?></p>
              <p>You will receive an email confirmation shortly on <?php echo e($order['billing_email']); ?></p>

              <a href="<?php echo e(url('/')); ?>" class="btn-round">Return to Shop</a> 
              </div>
          </div>
      </section>

</div>
<!-- End Content -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wcfood/project/resources/views/checkout/success.blade.php ENDPATH**/ ?>