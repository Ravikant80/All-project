  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style type="text/css">
	body {
    background: grey;
    margin-top: 120px;
    margin-bottom: 120px;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="row p-5">
                        <div class="col-md-6">
                            <!-- <img src="<?php echo e(asset('ecommerce/assets/images/logo.png')); ?>"> -->
                       
                        </div>

                        <div class="col-md-6 text-right">
                            <p class="font-weight-bold mb-1"><!-- Order Id: <?php echo e($subscribes->id); ?> --> </p>
                            <p class="text-muted">Subscribe Date: <?php echo date("d-m-Y, H:i:sa"); ?></p>
                         </div>
                    </div>

                        <!-- <h2>Order Received </h2> -->

                        <?php if(Auth::user()==true): ?>

                      <h3> Hi <?php echo e(isset(Auth::user()->name) ? Auth::user()->name : Auth::user()->email); ?><h3>
                        <h2> Thank you for Subscribe</h2>
                         <div class="row pb-5 p-5">
                                    <p class="font-weight-bold mb-4">Your Subscribe Email Information:</p>
                                    <p class="mb-1"><span class="text-muted">Email: </span> <?php echo e($subscribes->email); ?></p>
                                 
                               
                            </div>
                               <div class="text-light mt-5 mb-5 text-center small">©<?php echo e(date('Y')); ?> <a class="text-light" target="_blank" href="http://etwshoppingmall.com/">Wcfood.</a><?php echo app('translator')->getFromJson('All rights reserved.'); ?></div>

                            </div>

                         <?php else: ?>

                        <h2> Thank you for Subscribe</h2>
                      
                    <hr class="my-5">

                            <div class="row pb-5 p-5">
                                    <p class="font-weight-bold mb-4">Your Subscribe Email Information:</p>
                                    <p class="mb-1"><span class="text-muted">Email: </span> <?php echo e($subscribes->email); ?></p>
                                 
                               
                            </div>

                       
                        </div>    
                    </div>
                </div>
            </div>
        </div>
    </div>

       <!--  <p>you can get further details about your order by logging into our website</p>
        Thank you again for choosing us.
        Regards,<br/> -->

    <div class="text-light mt-5 mb-5 text-center small">©<?php echo e(date('Y')); ?> <a class="text-light" target="_blank" href="http://etwshoppingmall.com/">Wcfood.</a><?php echo app('translator')->getFromJson('All rights reserved.'); ?></div>

</div>


<?php endif; ?>








































<?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/emails/subscribe/subscribe.blade.php ENDPATH**/ ?>