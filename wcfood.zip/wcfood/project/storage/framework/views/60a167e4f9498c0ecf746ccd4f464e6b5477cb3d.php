<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
   <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area bg-image--24">
            <div class="ht__bradcaump__wrap d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="bradcaump__inner text-center brad__white">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area --> 

        <!-- Start Contact Map -->
        <div class="contact__map__area">
            <div class="contact__map__wrapper">
                <div class="contact__map__left">
                    <div class="map__thumb">
                        <img src="<?php echo e(asset('assets/images/banner/contact/1.jpg')); ?>" alt="images">
                    </div>
                </div>
                <div class="contact__map__right">
                    <div class="htc__google__map">
                        <div class="map-contacts">
                            <div id="googlemap"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contact Map -->

        <!-- Start Address -->
        <div class="food__contact">
            <div class="food__contact__wrapper d-flex flex-wrap flex-lg-nowrap">
                <!-- Start Single Contact -->
                <div class="contact">
                    <div class="ct__icon">
                        <i class="zmdi zmdi-phone"></i>
                    </div>
                    <div class="ct__address">
                        <p><a>Phone: 0120 412 9730</a></p>
                        <p><a>Phone: 0120 412 9730</a></p>
                    </div>
                </div>
                <!-- End Single Contact -->
                <!-- Start Single Contact -->
                <div class="contact">
                    <div class="ct__icon">
                        <i class="zmdi zmdi-home"></i>
                    </div>
                    <div class="ct__address">
                        <p>Address: A-90, 3rd Floor 201301,<br>  Sector 4, Noida, Uttar Pradesh 201301 </p>
                    </div>
                </div>
                <!-- End Single Contact -->

                <!-- Start Single Contact -->
                <div class="contact">
                    <div class="ct__icon">
                        <i class="zmdi zmdi-email"></i>
                    </div>
                    <div class="ct__address">
                        <p><a href="#">delivery@e-mail.com</a></p>
                        <p><a href="#">zaika.webcoir@gmail.com</a></p>
                    </div>
                </div>
                <!-- End Single Contact -->
            </div>
        </div>

        <!-- End Address -->
        <section class="food__contact__form bg--white section-padding--lg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="contact__form__wrap">
                            <h2>Get In Touch With Zaika</h2>
                            <div class="contact__form__inner">




    <!-- start form area -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Contact Register')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(url('/storecontus')); ?>">
                            
                                <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus onkeypress="return (event.charCode > 
                                     64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)"  maxlength="35">

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                                <div class="col-md-6">
                                    <input id="phone" type="tel" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" required autofocus>

                                    <?php if($errors->has('phone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                             <div class="form-group row">
                                <label for="message" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Message')); ?></label>

                                <div class="col-md-6">
                                    <input id="phone" type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="message" required autofocus >

                                </div>
                            </div>


                           
                            <div class="form-group row mb-0">


                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="food__btn" id="submit-email" >
                                        <?php echo e(__('Submit')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
</div>
</div>
</div>
</section>
<!-- End form area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\wcfood\project\resources\views/frontend/contact-us1.blade.php ENDPATH**/ ?>