<?php $__env->startSection('content'); ?>

<h1>gjkfgfgjfdgjdlgjlfdjglkfdjgdfljgfdjglfjfg</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wcfood/project/resources/views/thankyou.blade.php ENDPATH**/ ?>