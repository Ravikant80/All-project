<h1>success</h1>

//<?php echo e($data); ?><?php /**PATH /var/www/html/wcfood/project/resources/views/payment/status.blade.php ENDPATH**/ ?>