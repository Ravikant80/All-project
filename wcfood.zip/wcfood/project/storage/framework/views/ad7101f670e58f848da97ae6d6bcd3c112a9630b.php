<!DOCTYPE html>
<html>
<head>

</head>
<body>
	

<?php echo e($menucategory->type); ?>



</body>
</html><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/search/menucategory.blade.php ENDPATH**/ ?>