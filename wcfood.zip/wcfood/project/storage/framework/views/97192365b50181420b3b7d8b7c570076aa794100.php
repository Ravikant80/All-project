<?php $__env->startSection('style'); ?>

<link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
<!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
<!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

                <form method="post" id="add_restaurent_form_id" action="<?php echo e(url('admin/shipping-store')); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">


                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Country:</label>
                                        </div>
                                        <div class="col-md-4">
                                  <input type="text" id="countryid" name="country" class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" required  value="india"/>
                                         <?php if($errors->has('country')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('country')); ?></strong>
                                        </span>
                                         <?php endif; ?>


                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Price:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="priceid" name="price" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>"  value="<?php echo e(old('price')); ?>" min="1" required  />

                                            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div> 
 							<div class="col-md-12">

                                <div class="form-row">
                                    <div class="form-group col-md-4" >
                             
                              <label for="type" style="float: right;color: #468847;font-weight: bold;">Delivery Time:</label>

                                    </div> 
                                    <div class="form-group col-md-4" >
                                        <div class="row">
                                            <div class="col-md-6">

                                                Hrs.<select name="delivery_hour" class="form-control" style="border-color: #468847;" required >
                                                    <?php
                                                    for ($i = 0; $i <= 23; $i++) {
                                                        if ($i < 10) {
                                                            $min = 0;
                                                            $hours = $min . $i;
                                                        } else {
                                                            $hours = $i;
                                                        }
                                                        ?>
                                                        <option value="<?php echo $hours; ?>" >
                                                            <?php echo $hours; ?>
                                                        </option>
                                                        <?php
                                                    }
                                                    ?>


                                                </select>
                                                <?php if ($errors->has('opening_hour')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('opening_hour'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                               Mins <select name="delivery_minutes" class="form-control" style="border-color: #468847;" required>
                                                    <?php
                                                    for ($i = 15; $i <= 59; $i++) {
                                                        if ($i < 10) {
                                                            $min = 0;
                                                            $minutes = $min . $i;
                                                        } else {
                                                            $minutes = $i;
                                                        }
                                                        ?>
                                                        <option value="<?php echo $minutes; ?>">
                                                            <?php echo $minutes; ?>
                                                        </option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        	</div>
                         <div class="row">
                            <div class="col-md-12">
                              <center>  <button class="btn btn-primary btn-block btn-lg" style="width: auto;"><i class="fa fa-send"></i> Add Coupon</button></center>
                          </div>
                      </div>
                  </div>
              </form>
          </div>
      </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/admin/shipping/shipping_add.blade.php ENDPATH**/ ?>