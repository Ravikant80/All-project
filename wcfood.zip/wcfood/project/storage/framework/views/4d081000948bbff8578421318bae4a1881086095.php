<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<h2>listing here</h2>
</body>
</html><?php /**PATH /var/www/html/wcfood/project/resources/views/search/index.blade.php ENDPATH**/ ?>