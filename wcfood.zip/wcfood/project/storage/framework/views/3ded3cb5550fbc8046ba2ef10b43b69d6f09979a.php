<?php $__env->startSection('content'); ?> 

<!-- For Testing Purpose -->


    <title>Search</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
   
<div class="container">
    <h3>gagan</h3>   
    <input class="typeahead form-control" type="text" width="50px">
</div>
   



    <!-- typeahead javascript function -->
   
    <script type="text/javascript">
    var path = "<?php echo e(route('autocomplete')); ?>";
    $('input.typeahead').typeahead({
        source:  function (query, process) {
        return $.get(path, { query: query }, function (data) {
                return process(data);
            });
        }
    });
</script>
   




<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wcfood/project/resources/views/search/restomenusearch.blade.php ENDPATH**/ ?>