<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Restaurant Name.</th>
                        <th>Menu Name</th>
                        <th>Menu Description</th>
                        <th>view Menu </th>
                        <th>Add Menu Item</th>
                         <th>Edit Menu </th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($menu->id); ?></td>
                            <td><?php echo e($menu->name); ?></td>
                            <td><?php echo e($menu->menu_name); ?></td>
                            <td><?php echo e($menu->menu_description); ?></td>
                            <td><a href="<?php echo e(url('admin/menu-items/'.$menu->id)); ?>">View Items</a></td>
                            <td><a href="<?php echo e(url('admin/add-menu-items/'.$menu->id)); ?>">Add Menu Item</a></td>
                            <td><a href="<?php echo e(url('admin/restaurant-edit-menu/'.$menu->id)); ?>">Edit Menu</a></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div><!-- ROW-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/admin/restaurant/restaurant-menu.blade.php ENDPATH**/ ?>