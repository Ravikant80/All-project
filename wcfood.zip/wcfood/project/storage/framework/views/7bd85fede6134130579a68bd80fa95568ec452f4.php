                          <?php $__currentLoopData = $restaurantmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="beef_product">
                                    <div class="beef__thumb">
                                        <a>
                                            <img src="../assets/images/beef/1.jpg" alt="beef images">
                                        </a>
                                    </div>

                                    <div class="beef__details">
                                        <h4><i><?php echo e($menu->menu_name); ?></i></h4>
                                         <p>Top Item</p>

                                          <ul class="beef__prize">
                                            <li class="old__prize"></li>
                                            <li>Rs.<?php echo e($menu->price); ?></li>
                                          

                                            <form action="<?php echo e(url('addTocart')); ?>" method="post" enctype="multipart/form-data" id="cart_form" class="cart_form" name="cart_form">
                                                <?php echo csrf_field(); ?>
                                              <input type="hidden" name="restaurant_id" value="<?php echo e($menu->restaurant_id); ?>">
                                               <input type="hidden" name="product_id" value="<?php echo e($menu->menu_id); ?>">
                                               <input type="hidden" name="product_name" value="<?php echo e($menu->menu_name); ?>">
                                               <input type="hidden" name="product_price" value="<?php echo e($menu->price); ?>">
                                               <input type="hidden" name="product_quantity" value="1">
                                              <input type="submit" name="submit" value="ADD" class="add_btn _1RPOp">

                                           </form>

                                        </ul>
                                    </div>
                                </div>
                             </div>
                        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/fetchdata.blade.php ENDPATH**/ ?>