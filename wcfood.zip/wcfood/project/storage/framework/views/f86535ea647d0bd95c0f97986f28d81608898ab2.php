

<?php echo e($restaurantmenu); ?>


 <?php $__currentLoopData = $restaurantmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <h1><?php echo e($menu->menu_name); ?></h1>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/testdata.blade.php ENDPATH**/ ?>