<?php $__env->startSection('content'); ?>

<!-- Start Bradcaump area -->
<div class="ht__bradcaump__area bg-image--24">
    <div class="ht__bradcaump__wrap d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="bradcaump__inner text-center brad__white">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Bradcaump area --> 

<!-- Start Contact Map -->

<!-- End Contact Map -->

<!-- Start Address -->
<div class="food__contact">
    <div class="food__contact__wrapper d-flex flex-wrap flex-lg-nowrap">
        <!-- Start Single Contact -->
        <div class="contact">
            <div class="ct__icon">
                <i class="zmdi zmdi-phone"></i>
            </div>
            <div class="ct__address">
                <p><a>Phone: 0120 412 9730</a></p>
                <p><a>Phone: 0120 412 9730</a></p>
            </div>
        </div>
        <!-- End Single Contact -->
        <!-- Start Single Contact -->
        <div class="contact">
            <div class="ct__icon">
                <i class="zmdi zmdi-home"></i>
            </div>
            <div class="ct__address">
                <p>Address: A-90, 3rd Floor 201301,<br>  Sector 4, Noida, Uttar Pradesh 201301 </p>
            </div>
        </div>
        <!-- End Single Contact -->

        <!-- Start Single Contact -->
        <div class="contact">
            <div class="ct__icon">
                <i class="zmdi zmdi-email"></i>
            </div>
            <div class="ct__address">
                <p><a href="#">delivery@e-mail.com</a></p>
                <p><a href="#">zaika.webcoir@gmail.com</a></p>
            </div>
        </div>
        <!-- End Single Contact -->
    </div>
</div>

<!-- End Address -->
<section class="food__contact__form bg--white section-padding--lg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="contact__form__wrap">
                    <h2>Get In Touch With Zaika</h2>
                    <div class="contact__form__inner">


                        <!-- Contact-Us Form Started -->

                        <form id="contact-form" action="<?php echo e(url('/storecontus')); ?>" method="post">
                         <?php echo csrf_field(); ?>

                         <div class="single-contact-form">

                            <div class="contact-box name d-flex flex-wrap flex-md-nowrap flex-lg-nowrap justify-content-between">


                                <div class="form-group form-inline">
                                    <label for="name">Name:</label>
                                    <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="name" placeholder="Your name"  value="<?php echo e(old('name')); ?>" data-validation="alphanumeric" data-validation-allowing="-_" data-validation-length="max35">

                                    \
                                </div>


                                <div class="form-group form-inline">
                                    <label for="email">Email:</label>

                                    <input  type="email"  name="email"  placeholder="E-mail" value="<?php echo e(old('email')); ?>" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"  data-validation="email" data-validation-help="Som help info..." />


                                </div>


                                <div class="form-group form-inline">
                                    <label for="phone">Phone:</label>         
                                    <
                                    <input type="tel" name="phone" data-validation="number" 
                                    data-validation-optional-if-answered="cell-phone, work-phone"id="phone" class="form-control" class="form-control" value="<?php echo e(old('phone')); ?>">
                                    
                                </div>

                            </div>
                        </div>
                        <div class="single-contact-form">
                            <div class="contact-box message">
                                <textarea name="message"  placeholder="Message*"></textarea>
                            </div>
                        </div>
                        <div class="contact-btn">
                            <button type="submit" class="food__btn" id="submit-email" >
                            submit</button>
                        </div>
                    </form>

                </div>
                <div>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<script>

  function isNumberKey(evt)
  {
     var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

</script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
$.validate();
</script>


<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/frontend/jqury.blade.php ENDPATH**/ ?>