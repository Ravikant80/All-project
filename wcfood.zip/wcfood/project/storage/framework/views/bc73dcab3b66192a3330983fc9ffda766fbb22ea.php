<!DOCTYPE html>
<html>
<head>
</head>
<body>

<form action="<?php echo e(url('/smspost')); ?>" method="post">
	<?php echo csrf_field(); ?>
    <div class="col-md-4">
   <input type="tel" id="required2" name="mobile" class="form-control" required  maxlength="10" required >
</div>  
  <input type="submit" value="Submit">   

</form>


</html><?php /**PATH /var/www/html/wcfood/project/resources/views/demoform.blade.php ENDPATH**/ ?>