<?php $__env->startSection('content'); ?>


 <!-- <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.14.2/dist/bootstrap-table.min.css"> -->
<!-- <script src="https://unpkg.com/bootstrap-table@1.14.2/dist/bootstrap-table.min.js"></script> -->
<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
 -->
<!-- Latest compiled JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 -->
<!-- 
 <table class="table table-bordered">

  <thead>
    <tr>
      <th scope="col">ItemImage</th>
      <th scope="col">Cart Item Name</th>
      <th scope="col"> Single quantity price</th>
       <th scope="col">Total quantity</th>
        <th scope="col">Total Price</th>
          <th scope="col">Action</th>

    </tr>
  </thead>
  
  <tbody>

    <tr>
      <?php $__currentLoopData = $cartdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdatas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->

        <!-- <td><img src="assets/images/cart/2.jpg" alt="product img" /></a></td> -->
       <!--  <td>  <img src="assets/images/cart/2.jpg" class="img-rounded" alt="Cinque Terre" width="75" height="75"> 
        </td>  
      
        <td><?php echo e($cartdatas->name); ?></a></td>
        <td>Rs.<?php echo e($cartdatas->price); ?></span></td>
        <td> <?php echo e($cartdatas->quantity); ?> </td>
        <td>Rs.<?php echo e(Cart::get($cartdatas->id)->getPriceSum()); ?></td>

            <td> <a href="<?php echo e(url('/checkout-init')); ?>">
             <button type="button" class="btn">Reorder</button> 
             </a>
             &nbsp;<a href="<?php echo e(url('#')); ?>"> 
             <button type="button" class="btn">Help</button> 
            </a>

        </td>

        
    </tr>
  
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>

</table> -->



<div class="back_button">
  <a href="<?php echo e(url('/get-restaurant')); ?>">          
 <button type="button" class="btn">Back To Restaurant</button> 
</a>
</div>

 <?php if(Cart::getContent()->count() > 0): ?>

<!-- cart-main-area start -->

<div class="cart-main-area section-padding--lg bg--white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 ol-lg-12">
                <form action="#">               
                    <div class="table-content table-responsive">
                        <table>
                            <thead>
                                <tr class="title-top">
                                    <th class="product-thumbnail">Image</th>
                                    <th class="product-name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Total</th>
                          
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $cartdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdatas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php $pdata =getPoductDetails($cartdatas->id);  ?>

                                <tr>
                                    <td class="product-thumbnail"><a href="#"><img src="assets/images/cart/2.jpg" alt="product img" /></a></td>
                                    <td class="product-name"><a href="#"><?php echo e($cartdatas->name); ?></a></td>
                                    <input type="hidden" name="product_id" value="<?php echo e($cartdatas->id); ?>" id="product_id">
                                    <td class="product-price"><span class="amount">Rs.<?php echo e($cartdatas->price); ?></span></td>
                                   <!--  <td class="product-quantity"><input type="number" value="<?php echo e($cartdatas->quantity); ?>" /> 
                                    </td> -->

                                    <td class="text-center" >                              
                                    <div class="quinty padding-top-20">           
                                     <div class="cart-info quantity ">
            <div class="btn-increment-decrement decrement custombutton" onClick="decrement_quantity(<?php echo e($cartdatas->id); ?>)">-</div>
                        <input class="input-quantity "
                            id="input-quantity-<?php echo e($cartdatas->id); ?>" value="<?php echo e($cartdatas->quantity); ?>">
                                        <div class="btn-increment-decrement increment custombutton"
                                        onClick="increment_quantity(<?php echo e($cartdatas->id); ?>)">+</div>
                                </div>




                            </div>


                            </td>

                
            <td class="product-subtotal">Rs.<?php echo e(Cart::get($cartdatas->id)->getPriceSum()); ?></td>
              
                                </tr>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </form> 



<?php $__env->stopSection(); ?>

<script>
function increment_quantity(cart_id) {
    var inputQuantityElement = $("#input-quantity-"+cart_id);
    var newQuantity = parseInt($(inputQuantityElement).val())+1;
    save_to_db(cart_id, newQuantity);
}

function decrement_quantity(cart_id) {
    var inputQuantityElement = $("#input-quantity-"+cart_id);
    if($(inputQuantityElement).val() > 1) 
    {
    var newQuantity = parseInt($(inputQuantityElement).val()) - 1;
    save_to_db(cart_id, newQuantity);
    }
}

function save_to_db(cart_id, new_quantity) {
    var inputQuantityElement = $("#input-quantity-"+cart_id);
    $.ajax({
        url : "cart/update-quantity",
        data :{_token: '<?php echo e(csrf_token()); ?>',cart_id:cart_id,new_quantity:new_quantity},
        type : 'post',
        success : function(response) {

           // alert(response);

            $(inputQuantityElement).val(new_quantity);
                  window.location.reload();

        }
    });
}
</script>
<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wcfood/project/resources/views/cart/cartinfo.blade.php ENDPATH**/ ?>