<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="<?php echo e(url('/get_filter')); ?>" method="GET">
    <input type="text" name="min_price">   
    <input type="text" name="max_price">  
    <input type="text" name="keyword" >  
    <input type="submit" value="Filter">
</form>
</body>
</html><?php /**PATH /var/www/html/wcfood/project/resources/views/cart/demofilter.blade.php ENDPATH**/ ?>