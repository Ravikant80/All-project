
                <?php $__env->startSection('content'); ?>

                  <!-- Linking -->
                <div class="linking">
                  <div class="container">
                    <ol class="breadcrumb">
                      <li><a href="<?php echo e(url('/get-restaurant')); ?>"> Go To Restaurant</a></li>
                      <li class="active">Search</li>
                    </ol>
                </div>
            </div>
                <!-- Content -->

                 <?php if($rests->count() > 0): ?>
                    <!-- Products -->
                    <section class="padding-top-40 padding-bottom-60">
                    <div class="container">
                      <div class="row">

                        <!-- Shop Side Bar -->
                        <div class="col-md-3">
                        
                        </div>

                        <!-- Products -->
                        <div class="col-md-9">

                          <!-- Short List -->
                          <div class="short-lst">
                                <h2> Search Results 
                                <span style="float:right">
                                <?php echo e($rests->count()); ?> Item(s) for <?php echo e(request()->input('query')); ?> 
                                </span>
                                </h2>
                            </div>
                           <!-- Items -->
                                <div class="item-col-4">
                                    <table class="table table-bordered">
                                    <thead>
                                      <tr>
                                      <th scope="col">ItemName</th>
                                      </tr>
                                    </thead>
                                   <?php $__currentLoopData = $rests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                      <tr>
                                          <td><?php echo e($rest->menu_name); ?></td>
                                      </tr>
                                  
                                    </tbody>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  <?php echo e($rests->links()); ?>


                                </table>

                                  </div>
                              </div>
                          </div>
                      </div>
                </section>
                <?php else: ?>
                <!-- Oder-success -->
                <section>
                     <div class="container">
                     
    
                    <div>
                      <a href="#">
                        <center>  <img src="<?php echo e(asset('assets/images/pnot.jpg')); ?>" alt="logo images">

                        </center>
                        </a>
                        <center> <h5>We couldn’t find any items matching your search. Please try a new keyword.</h5></center>

                      <!--   <center><a href="<?php echo e(url('/get-restaurant')); ?>" class="btn-round">Return to Restaurant List</a><center>  -->


                          <center> <a href="<?php echo e(url('/get-restaurant')); ?>"class="btn btn-primary a-btn-slide-text mr-4 ">
                        <!-- <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> -->
                        <span><strong>Go To Restaurant</strong></span>            
                        </a>
                       </center>
                    </div>


                    <div class="container">
                    
                                                    
                    </div> 
                   
                  </div>
              </section>
            <?php endif; ?>
          </div>
    <?php $__env->stopSection(); ?>
                          
                      
             
            




                 <?php /**PATH /var/www/html/wcfood/project/resources/views/search/search-result.blade.php ENDPATH**/ ?>