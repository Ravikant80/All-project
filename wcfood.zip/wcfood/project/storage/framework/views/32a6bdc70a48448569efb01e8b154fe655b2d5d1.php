<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                </div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="sample_1">

                    <thead>
                    <tr>
                        <th>SNo.</th>
                        <th>ID#</th>
                        <th>Country</th>
                        <th>Price</th>
                        <th>Time(Hrs:Mins)</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($shipping->id); ?></td>
                            <td><?php echo e($shipping->country); ?></td>
                            <td><?php echo e($shipping->price); ?> INR</td>
                            <td><?php echo e($shipping->type); ?></td>
                            <td><a href="<?php echo e(url('admin/shipping-edit/'.$shipping->id)); ?>">Edit</a></td>
                            <td><a href="<?php echo e(url('admin/shipping-show/'.$shipping->id)); ?>">show</a></td>
                            <td><a href="<?php echo e(url('admin/shipping-delete/'.$shipping->id)); ?>" onclick="return myFunction();">Delete</a></td> 
                        </tr>          
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <div class="text-center">

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
function myFunction() {
if(!confirm("Are You Sure to delete this"))
event.preventDefault();
}
</script>
<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/admin/shipping/shipping_view.blade.php ENDPATH**/ ?>