<?php $__env->startSection('style'); ?>

    <link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
    <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"> -->
    <!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

                <form method="post" id="update_coupon_form_id" action="<?php echo e(url('admin/update-coupon/'.$coupon->id)); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">


                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Coupon Code:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="text" id="coupon_code" name="coupon_code" class="form-control" required  value="<?php echo e($coupon->coupon_code); ?>" maxlength="10" minlength="10" />

                                          
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Amount:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="amount" name="amount" class="form-control" required  value="<?php echo e($coupon->amount); ?>"/>
                                        </div>
                                    </div>
                                </div>
                            </div> 

                              <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Expire Date:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="date" id="expire_date" name="expire_date" class="form-control" required  value="<?php echo e($coupon->expire_date); ?>" autocomplete="off" />
                                        </div>
                                    </div>
                                </div>
                            </div> 

                       
                         
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Amount Type:</label>
                                        </div>
                                        <div class="col-md-4">

                                            <select name="amount_type" id="amount_type">
                                            <option value="Percentage" <?php if($coupon->amount_type =='Percentage'){ echo "selected";}?>>Percentage</option>
                                            <option value="Fixed" <?php if($coupon->amount_type =='Fixed'){ echo "selected";}?>>Fixed</option>
                                         
                                        </select>

                                        </div>
                                    </div>
                                </div>
                            </div> 
                        </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Enable:</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="checkbox" id="status" name="status" class="form-control"required value="1" <?php if($coupon->status=="1") echo "checked";?> />
                                        </div>
                                    </div>
                                </div>
                            </div> 


                            <div class="row">
                                <div class="col-md-12">
                                  <center>  <button class="btn btn-primary btn-block btn-lg" style="width: auto;"><i class="fa fa-send"></i> Edit Coupon</button></center>
                                </div>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/admin_dashboard/edit_coupon.blade.php ENDPATH**/ ?>