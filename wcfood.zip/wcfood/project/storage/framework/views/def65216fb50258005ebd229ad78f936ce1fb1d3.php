<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <strong class="uppercase"><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse"> </a>
                </div>
            </div>
            <div class="portlet-body" style="overflow: hidden">

                <form method="post" id="add_restaurent_form_id" action=" <?php echo e(url('admin/add-menu-items')); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">


                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <input type="hidden" id="required2" name="menu_id" class="form-control" required value="<?php echo e($menu->id); ?>" />
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name"> Item Name:</label>
                                        </div>
                                        <div class="col-md-4">
                            <input type="text" id="required2" name="item_name" class="form-control" required value="<?php echo e(old('item_name')); ?>" onkeypress="return (event.charCode > 
                                            64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)" />

                                              <?php if ($errors->has('item_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('item_name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                           
                       
  
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="form-group col-md-4" >
                                            <label class="control-label control_name">Price: </label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" id="required2" name="price" class="form-control" required value="<?php echo e(old('price')); ?>"/>
                                                <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
 
     

                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <button class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> Add Menu Item</button>
                                </div>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin_dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/admin/restaurant/add-menu-item.blade.php ENDPATH**/ ?>