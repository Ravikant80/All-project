<!DOCTYPE html>
<html>
<head>
	<title>hello ravikant</title>
</head>
<body>
<h2>Session data here</h2>
<?php echo e($value); ?>


</body>
</html><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/session.blade.php ENDPATH**/ ?>