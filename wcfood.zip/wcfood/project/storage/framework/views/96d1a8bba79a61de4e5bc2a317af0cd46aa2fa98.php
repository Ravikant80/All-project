<?php $__env->startSection('content'); ?>

<center><h2><i>My Order</i></h2></center>
 <?php if($userorders->count() > 0): ?>

<!-- cart-main-area start -->

<div class="cart-main-area section-padding--lg bg--white">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 ol-lg-12">
                <form action="#" method="post"> 
                    <?php echo csrf_field(); ?>              
                    <div class="table-content table-responsive">
                        <table>
                            <thead>
                                <tr class="title-top">
                              
                                    <th class="product-subtotal">Product Name</th>
                                   <!--  <th class="product-subtotal">Product Image</th> -->
                                    <th class="product-subtotal">Quantity</th>
                                       <th class="product-subtotal">Total</th>
                                       <th class="product-subtotal">Status</th>
                                    <th class="product-subtotal">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                	   <?php $__currentLoopData = $userorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <td><?php echo e($order->item_name); ?></td>
                         <td><?php echo e($order->quantity); ?></td>
           
                     </div>
 
            </td>




            <td><?php echo e($order->billing_total); ?></td>
            <td><?php echo e($order->order_status); ?></td>
             <td>
                <a href="<?php echo e(url('/checkout-init')); ?>">
              
             <button type="button" class="btn btn-info">Reorder</button> 
            </a>
            </td> 
                       
            </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
            </form> 
           
            </div>
        </div>
    </div>  
</div>


   
<?php else: ?>
<section class="food__acconrdion__area bg--white section-padding--lg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="section__title title__style--2 service__align--center">
                    <h2 class="title__line">You Have No Orders</h2>
                    <a href="<?php echo e(url('/')); ?>">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>
</section>
  
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wcfood\project\resources\views/cart/myorder.blade.php ENDPATH**/ ?>