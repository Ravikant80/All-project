<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo e($products); ?>


</body>
<?php /**PATH /var/www/html/wcfood/project/resources/views/cart/show_filterdata.blade.php ENDPATH**/ ?>