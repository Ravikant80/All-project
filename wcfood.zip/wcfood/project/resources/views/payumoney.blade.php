@extends('frontend.template')
@section('content')
<center><h2>payment view here</h2></center>

@endsection