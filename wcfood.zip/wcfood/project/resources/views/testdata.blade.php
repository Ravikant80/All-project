

{{$restaurantmenu}}

 @foreach($restaurantmenu as $menu )
 <h1>{{$menu->menu_name}}</h1>

    @endforeach