                        
@if(count($restaurantmenu) ==0)
<!-- <h2 style="margin:auto;">No Data Found</h2> -->
<img src="{{asset('assets/images/pnot.jpg')}}" alt="logo images" style="margin: auto;">
@else

@foreach($restaurantmenu as $menu)

<div class="col-lg-6 col-md-6 col-sm-12 ">
  <div class="beef_product">
    <div class="beef__thumb">
      <a>
        <img src="../assets/images/beef/1.jpg" alt="beef images">
                 <!--  <img id="menuimg" src="{{ URL::asset('assets/upload/restaurant/' .$menu->menuimg) }}" alt="{{ $menu->menuimg }}" class="img-responsive food_img" >


                      <input type="hidden" name="product_id" value="{{$menu->menu_id}}" id="productId">
                    -->                     
                  </a>
                </div>

                <div class="beef__details">
                  <h4><i>{{$menu->menu_name}}</i></h4>
                  <h5><i>Cat: {{ $menu->item_name}}</i></h5>
                  <!-- <p>Product descriptions play a huge part in generating sales.</p> -->

                  <ul class="beef__prize">
                    <li class="old__prize"></li>
                    <li>Rs.{{ $menu->price }}</li>
                    

                    <form action="{{url('addTocart1')}}" method="post" enctype="multipart/form-data" id="cart_form" class="cart_form" name="cart_form">
                      @csrf
                      <input type="hidden" name="product_id" value="{{$menu->menu_id}}" id="restaurantId">
                      <input type="hidden" name="product_name" value="{{$menu->menu_name}}" id="restaurantId">
                      <input type="hidden" name="product_price" value="{{$menu->price}}" id="restaurantId">
                      <input type="hidden" name="restaurant_id" value="{{$menu->restaurant_id}}" id="restaurantId">
                      <input type="hidden" name="product_quantity" value="1" id="productQuantity">
                      <input type="button" name="submit" value="ADD" class="add_btn _1RPOp" id="cart-{{$menu->menu_id}}" onclick="doaddCart('{{$menu->menu_id}}','{{$menu->menu_name}}','{{$menu->price}}')">

                      <!-- <input type="submit" name="submit" value="ADD" class="add_btn _1RPOp" id="cart-{{$menu->menu_id}}"> -->

                    </form>

                  </ul>
                </div>
              </div>
            </div>
            @endforeach
            
            @endif