<!DOCTYPE html>
<html>

<body>
	@foreach($rests as $resto)

		{{$resto->menu_name}}

	@endforeach
</body>
</html>