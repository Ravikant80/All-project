<!DOCTYPE html>
<html>
<head>

</head>
<body>
	

{{$menucategory->type}}


</body>
</html>